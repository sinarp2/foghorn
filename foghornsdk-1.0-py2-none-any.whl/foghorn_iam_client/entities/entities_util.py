# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l1111_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l_opy_ = ord (ll_opy_ [-1])
    l11l1_opy_ = ll_opy_ [:-1]
    l111l_opy_ = l11l_opy_ % len (l11l1_opy_)
    l111_opy_ = l11l1_opy_ [:l111l_opy_] + l11l1_opy_ [l111l_opy_:]
    if l1_opy_:
        l1l1_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1lll_opy_ + l11l_opy_) % l1111_opy_) for l1lll_opy_, char in enumerate (l111_opy_)])
    else:
        l1l1_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1lll_opy_ + l11l_opy_) % l1111_opy_) for l1lll_opy_, char in enumerate (l111_opy_)])
    return eval (l1l1_opy_)
import logging
logger = logging.getLogger()
creds_user_creds_key = l1l1l_opy_ (u"ࠤࡸࡷࡪࡸࡃࡳࡧࡧࡷࠧ࠯")
creds_app_creds_key = l1l1l_opy_ (u"ࠥࡥࡵࡶࡃࡳࡧࡧࡷࠧ࠰")
creds_access_token_key = l1l1l_opy_ (u"ࠦࡦࡩࡣࡦࡵࡶࡘࡴࡱࡥ࡯ࡋࡱࡪࡴࠨ࠱")
usercreds_username_key = l1l1l_opy_ (u"ࠧࡻࡳࡦࡴࡱࡥࡲ࡫ࠢ࠲")
usercreds_password_key = l1l1l_opy_ (u"ࠨࡰࡢࡵࡶࡻࡴࡸࡤࠣ࠳")
appcreds_client_id_key = l1l1l_opy_ (u"ࠢࡤ࡮࡬ࡩࡳࡺࡉࡥࠤ࠴")
appcreds_client_secret_key = l1l1l_opy_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡔࡧࡦࡶࡪࡺࠢ࠵")
accesstoken_token_value_key = l1l1l_opy_ (u"ࠤࡷࡳࡰ࡫࡮ࠣ࠶")
accesstoken_token_type_key = l1l1l_opy_ (u"ࠥࡸࡾࡶࡥࠣ࠷")
accesstoken_refresh_token_key = l1l1l_opy_ (u"ࠦࡷ࡫ࡦࡳࡧࡶ࡬࡙ࡵ࡫ࡦࡰࠥ࠸")
accesstoken_exp_time_key = l1l1l_opy_ (u"ࠧ࡫ࡸࡱ࡫ࡵࡥࡹ࡯࡯࡯ࡖ࡬ࡱࡪࠨ࠹")
accesstoken_scope_key = l1l1l_opy_ (u"ࠨࡳࡤࡱࡳࡩࠧ࠺")
accesstoken_addl_info_key = l1l1l_opy_ (u"ࠢࡢࡦࡧ࡭ࡹ࡯࡯࡯ࡣ࡯ࡍࡳ࡬࡯ࠣ࠻")
default_token_type = l1l1l_opy_ (u"ࠣࡤࡨࡥࡷ࡫ࡲࠣ࠼")
validation_authentication_key = l1l1l_opy_ (u"ࠤ࡬ࡷࡆࡻࡴࡩࡧࡱࡸ࡮ࡩࡡࡵࡧࡧࠦ࠽")
validation_principal_key = l1l1l_opy_ (u"ࠥࡴࡷ࡯࡮ࡤ࡫ࡳࡥࡱࠨ࠾")
validation_authorities_key = l1l1l_opy_ (u"ࠦࡦࡻࡴࡩࡱࡵ࡭ࡹ࡯ࡥࡴࠤ࠿")
error_http_status_key = l1l1l_opy_ (u"ࠧ࡮ࡴࡵࡲࡖࡸࡦࡺࡵࡴࡅࡲࡨࡪࠨࡀ")
error_detail_message_key = l1l1l_opy_ (u"ࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢࡁ")
error_error_code_key = l1l1l_opy_ (u"ࠢࡦࡴࡵࡳࡷࡉ࡯ࡥࡧࠥࡂ")
error_error_message_key = l1l1l_opy_ (u"ࠣࡧࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࠢࡃ")
def get_access_token_obj(token_value, exp_time, token_type, refresh_token_value, scope=None, addl_info=None):
    l1l1l_opy_ (u"ࠤࠥࠦࠏࠐࠠࠡࠢࠣ࠾ࡷࡺࡹࡱࡧ࠽ࠤࡲࡧࡰࠡࡱࡥ࡮ࡪࡩࡴࠡࡱࡩࠤࡹ࡮ࡥࠡࡣࡦࡧࡪࡹࡳࠡࡶࡲ࡯ࡪࡴࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡺ࡯࡬ࡧࡱࡣࡻࡧ࡬ࡶࡧ࠽ࠤࡸࡺࡲࡪࡰࡪࠤࡻࡧ࡬ࡶࡧࠣࡪࡴࡸࠠࡵࡪࡨࠤࡦࡩࡣࡦࡵࡶࠤࡹࡵ࡫ࡦࡰࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡦࡺࡳࡣࡹ࡯࡭ࡦ࠼ࠣࡰࡴࡴࡧࠡࡸࡤࡰࡺ࡫ࠠࡳࡧࡳࡶࡪࡹࡥ࡯ࡶ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡸ࡮ࡳࡥࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡺ࡯࡬ࡧࡱࡣࡹࡿࡰࡦ࠼ࠣࡷࡹࡸࡩ࡯ࡩࠣࡺࡦࡲࡵࡦࠢࡩࡳࡷࠦࡴࡩࡧࠣࡸࡴࡱࡥ࡯ࠢࡷࡽࡵ࡫ࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡷ࡫ࡦࡳࡧࡶ࡬ࡤࡺ࡯࡬ࡧࡱࡣࡻࡧ࡬ࡶࡧ࠽ࠤࡸࡺࡲࡪࡰࡪࠤࡻࡧ࡬ࡶࡧࠣࡪࡴࡸࠠࡵࡪࡨࠤࡷ࡫ࡦࡳࡧࡶ࡬ࠥࡼࡡ࡭ࡷࡨࠤࡴ࡬ࠠࡵࡪࡨࠤࡹࡵ࡫ࡦࡰࠍࠤࠥࠦࠠ࠻ࡲࡤࡶࡦࡳࠠࡴࡥࡲࡴࡪࡀࠠࡴࡧࡷࠤࡴ࡬ࠠࡴࡥࡲࡴࡪࡹࠠࡥࡧࡩ࡭ࡳ࡫ࡤࠡࡱࡱࠤࡹ࡮ࡥࠡࡶࡲ࡯ࡪࡴࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡦࡪࡤ࡭ࡡ࡬ࡲ࡫ࡵ࠺ࠡࡣࡧࡨ࡮ࡺࡩࡰࡰࡤࡰࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰࠣࡱࡦࡶࠠࡰࡨࠣ࡯ࡪࡿࠠࡢࡰࡧࠤࡻࡧ࡬ࡶࡧࠣࡴࡦ࡯ࡲࡴࠌࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡࡣࡦࡧࡪࡹࡳࠡࡶࡲ࡯ࡪࡴࠠࡰࡤ࡭ࡩࡨࡺࠊࠡࠢࠣࠤࠥࠦࠠࠡࡽࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡷࡳࡰ࡫࡮ࠣࠢ࠽ࠤࡁࡼࡡ࡭ࡷࡨࡂ࠱ࠦࠢࡵࡻࡳࡩࠧࠦ࠺ࠡ࠾ࡷࡽࡵ࡫ࡖࡢ࡮ࡸࡩࡃ࠲ࠠࠣࡧࡻࡴ࡙࡯࡭ࡦࠤࠣ࠾ࠥ࠸࠹࠵࠴࠯ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡶࡪ࡬ࡲࡦࡵ࡫ࡘࡴࡱࡥ࡯ࠤࠣ࠾ࠥࡂࡲࡦࡨࡵࡩࡸ࡮ࡔࡰ࡭ࡨࡲ࡛ࡧ࡬ࡶࡧࡁ࠰ࠥࠨࡳࡤࡱࡳࡩࠧࠦ࠺ࠡ࡝ࠣࡀࡸ࠷࠾࠭ࠢ࠿ࡷ࠷ࡄࠠ࡞࠮ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡤࡨࡩ࡯ࡴࡪࡱࡱࡥࡱࡏ࡮ࡧࡱࠥࠤ࠿ࠦࡻࠡ࠾࡮ࡩࡾ࠷࠾ࠡ࠼ࠣࡀࡻࡧ࡬ࡶࡧ࠴ࡂ࠱ࠦ࠼࡬ࡧࡼ࠶ࡃࠦ࠺ࠡ࠾ࡹࡥࡱࡻࡥ࠳ࡀࠣࢁࠏࠦࠠࠡࠢࠣࠤࠥࠦࡽࠋࠢࠣࠤࠥࠨࠢࠣࡄ")
    if token_value is None:
        return None
    access_token_dict = {accesstoken_token_value_key: token_value}
    if token_type is None:
        access_token_dict[accesstoken_token_type_key] = default_token_type
    else:
        access_token_dict[accesstoken_token_type_key] = token_type
    if exp_time >= 0:
        access_token_dict[accesstoken_exp_time_key] = exp_time
    else:
        access_token_dict[accesstoken_exp_time_key] = 0
    if refresh_token_value is not None:
        access_token_dict[accesstoken_refresh_token_key] = refresh_token_value
    if len(scope) > 0:
        access_token_dict[accesstoken_scope_key] = scope
    if len(addl_info) > 0:
        access_token_dict[accesstoken_addl_info_key] = addl_info
    return access_token_dict
def get_credentials_obj(username, password, client_id, client_secret, access_token_obj=None):
    l1l1l_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࡑࡪࡺࡨࡰࡦࠣࡶࡪࡺࡵࡳࡰࡶࠤࡹ࡮ࡥࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࠦࡪࡴࡱࡱࠤࡴࡨࡪࡦࡥࡷࠤࡧࡿࠠࡤࡱࡱࡷࡹࡸࡵࡤࡶ࡬ࡲ࡬ࠦࡩࡵࠢࡸࡷ࡮ࡴࡧࠡࡶ࡫ࡩࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰࠣࡴࡷࡵࡶࡪࡦࡨࡨࠏࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡹࡸ࡫ࡲ࡯ࡣࡰࡩ࠿ࠦࡳࡵࡴ࡬ࡲ࡬ࠦࡶࡢ࡮ࡸࡩࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡵࡴࡧࡵࡲࡦࡳࡥࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡶࡡࡴࡵࡺࡳࡷࡪ࠺ࠡࡵࡷࡶ࡮ࡴࡧࠡࡸࡤࡰࡺ࡫ࠠࡧࡱࡵࠤࡹ࡮ࡥࠡࡷࡶࡩࡷࠦࡰࡢࡵࡶࡻࡴࡸࡤࠋࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡩ࡬ࡪࡧࡱࡸࡤ࡯ࡤ࠻ࠢࡶࡸࡷ࡯࡮ࡨࠢࡹࡥࡱࡻࡥࠡࡨࡲࡶࠥࡺࡨࡦࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡤ࡮࡬ࡩࡳࡺࡉࡥࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡣ࡭࡫ࡨࡲࡹࡥࡳࡦࡥࡵࡩࡹࡀࠠࡴࡶࡵ࡭ࡳ࡭ࠠࡷࡣ࡯ࡹࡪࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡩ࡬ࡪࡧࡱࡸࡘ࡫ࡣࡳࡧࡷࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡣࡦࡧࡪࡹࡳࡠࡶࡲ࡯ࡪࡴ࡟ࡰࡤ࡭࠾ࠥࡳࡡࡱࠢࡲࡦ࡯࡫ࡣࡵࠢࡦࡳࡳࡺࡡࡪࡰ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡥࡨࡩࡥࡴࡵࠣࡸࡴࡱࡥ࡯ࠢ࡬ࡲ࡫ࡵࡲ࡮ࡣࡷ࡭ࡴࡴࠊࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠦ࡭ࡢࡲࠣࡳࡧࡰࡥࡤࡶࠣࡳ࡫ࠦࡴࡩࡧࠣࡧࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡶ࡫ࡥࡹࠦࡣࡢࡰࠣࡦࡪࠦࡵࡴࡧࡧࠤࡹࡵࠠࡳࡧࡩࡶࡪࡹࡨࠡࡱࡵࠤ࡫࡫ࡴࡤࡪࠣࡲࡪࡽࠠࡢࡥࡦࡩࡸࡹࠠࡵࡱ࡮ࡩࡳࠐࠠࠡࠢࠣࠤࠥࠦࠠࡼࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠣࡷࡶࡩࡷࡉࡲࡦࡦࡶࠦࠥࡀࠠࡼࠢࠥࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠧࠦ࠺ࠡ࠾ࡸࡷࡪࡸ࡮ࡢ࡯ࡨࡂ࠱ࠦࠢࡱࡣࡶࡷࡼࡵࡲࡥࠤࠣ࠾ࠥࡂࡰࡢࡵࡶࡻࡴࡸࡤ࠿ࠢࢀ࠰ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠦࡦࡶࡰࡄࡴࡨࡨࡸࠨࠠ࠻ࠢࡾࠤࠧࡩ࡬ࡪࡧࡱࡸࡎࡪࠢࠡ࠼ࠣࡀ࡮ࡪ࠾࠭ࠢࠥࡧࡱ࡯ࡥ࡯ࡶࡖࡩࡨࡸࡥࡵࠤࠣ࠾ࠥࡂࡳࡦࡥࡵࡩࡹࡄࠠࡾ࠮ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡤࡧࡨ࡫ࡳࡴࡖࡲ࡯ࡪࡴࡉ࡯ࡨࡲࠦࠥࡀࠠࡼࠢࠥࡸࡴࡱࡥ࡯ࠤࠣ࠾ࠥࡂࡶࡢ࡮ࡸࡩࡃ࠲ࠠࠣࡶࡼࡴࡪࠨࠠ࠻ࠢ࠿ࡸࡾࡶࡥࡗࡣ࡯ࡹࡪࡄࠬࠡࠤࡨࡼࡵ࡚ࡩ࡮ࡧࠥࠤ࠿ࠦ࠲࠺࠶࠵࠰ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠣࡴࡨࡪࡷ࡫ࡳࡩࡖࡲ࡯ࡪࡴࠢࠡ࠼ࠣࡀࡷ࡫ࡦࡳࡧࡶ࡬࡙ࡵ࡫ࡦࡰ࡙ࡥࡱࡻࡥ࠿࠮ࠣࠦࡸࡩ࡯ࡱࡧࠥࠤ࠿࡛ࠦࠡ࠾ࡶ࠵ࡃ࠲ࠠ࠽ࡵ࠵ࡂࠥࡣࠬࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠦࡦࡪࡤࡪࡶ࡬ࡳࡳࡧ࡬ࡊࡰࡩࡳࠧࠦ࠺ࠡࡽࠣࡀࡰ࡫ࡹ࠲ࡀࠣ࠾ࠥࡂࡶࡢ࡮ࡸࡩ࠶ࡄࠬࠡ࠾࡮ࡩࡾ࠸࠾ࠡ࠼ࠣࡀࡻࡧ࡬ࡶࡧ࠵ࡂࠥࢃࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࢃࠊࠡࠢࠣࠤࠥࠦࠠࠡࡿࠍࠤࠥࠦࠠࠣࠤࠥࡅ")
    usercreds_dict = {}
    appcreds_dict = {}
    creds_dict = {}
    if username is not None and password is not None:
        usercreds_dict[usercreds_username_key] = username
        usercreds_dict[usercreds_password_key] = password
    if client_id is not None and client_secret is not None:
        appcreds_dict[appcreds_client_id_key] = client_id
        appcreds_dict[appcreds_client_secret_key] = client_secret
    if len(usercreds_dict) > 0:
        creds_dict[creds_user_creds_key] = usercreds_dict
    if len(appcreds_dict) > 0:
        creds_dict[creds_app_creds_key] = appcreds_dict
    if access_token_obj is not None and len(access_token_obj) > 0:
        creds_dict[creds_access_token_key] = access_token_obj
    return creds_dict
def get_error_response_obj(http_status_code, detail_message, error_code_str=None, error_message=None):
    l1l1l_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࡗ࡫ࡴࡶࡴࡱࡷࠥࡺࡨࡦࠢࡨࡶࡷࡵࡲࠡࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡳࡧࡰࡥࡤࡶࠣࡧࡴࡴࡳࡵࡴࡸࡧࡹ࡫ࡤࠡࡷࡶ࡭ࡳ࡭ࠠࡵࡪࡨࠤࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࡳࠡࡲࡵࡳࡻ࡯ࡤࡦࡦࠍࠎࠥࠦࠠࠡ࠼ࡵࡸࡾࡶࡥ࠻ࠢࡈࡶࡷࡵࡲࠡࡔࡨࡷࡵࡵ࡮ࡴࡧࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡰࡤ࡭ࡩࡨࡺࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡭ࡺࡴࡱࡡࡶࡸࡦࡺࡵࡴࡡࡦࡳࡩ࡫࠺ࠡࡊࡗࡘࡕࠦࡩ࡯ࡶࡨ࡫ࡪࡸࠠࡴࡶࡤࡸࡺࡹࠠࡤࡱࡧࡩࠥࡺ࡯ࠡࡲࡸࡸࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡵࡢ࡫ࡧࡦࡸࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡧࡩࡹࡧࡩ࡭ࡡࡰࡩࡸࡹࡡࡨࡧ࠽ࠤࡉ࡫ࡴࡢ࡫࡯ࡩࡩࠦࡳࡵࡴ࡬ࡲ࡬ࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡢࡵࡶࡳࡨ࡯ࡡࡵࡧࡧࠤࡼ࡯ࡴࡩࠢࡷ࡬ࡪࠦࡥࡳࡴࡲࡶࠥࡳࡥࡴࡵࡤ࡫ࡪࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡩࡷࡸ࡯ࡳࡡࡦࡳࡩ࡫࡟ࡴࡶࡵ࠾࡙ࠥࡴࡳ࡫ࡱ࡫ࠥࡼࡡ࡭ࡷࡨࠤࡴ࡬ࠠࡵࡪࡨࠤࡸࡺࡡࡵࡷࡶࠤࡨࡵࡤࡦࠢ࡬ࡪࠥࡧ࡮ࡺࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡥࡳࡴࡲࡶࡤࡳࡥࡴࡵࡤ࡫ࡪࡀࠠࡄࡷࡶࡸࡴࡳࠠࡦࡴࡵࡳࡷࠦ࡭ࡦࡵࡶࡥ࡬࡫ࠠࡢࡵࡶࡳࡨ࡯ࡡࡵࡧࡧࠎࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯࠼ࠣࡉࡷࡸ࡯ࡳࠢࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡴࡨࡪࡦࡥࡷࠤࡴ࡬ࠠࡵࡻࡳࡩࠏࠦࠠࠡࠢࠣࠤࠥࠦࡻࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠢࡩࡶࡷࡴࡘࡺࡡࡵࡷࡶࡇࡴࡪࡥࠣࠢ࠽ࠤࡁࡩ࡯ࡥࡧࡁ࠰ࠥࠨ࡭ࡦࡵࡶࡥ࡬࡫ࠢࠡ࠼ࠣࡀࡲ࡫ࡳࡴࡣࡪࡩࡤࡹࡴࡳ࡫ࡱ࡫ࡃ࠲ࠠࠣࡧࡵࡶࡴࡸࡃࡰࡦࡨࠦࠥࡀࠠ࠽ࡧࡵࡶࡴࡸࡃࡰࡦࡨࡗࡹࡸࡩ࡯ࡩࡁ࠰ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠦࡪࡸࡲࡰࡴࡐࡩࡸࡹࡡࡨࡧࠥࠤ࠿ࠦ࠼ࡦࡴࡵࡳࡷࡓࡥࡴࡵࡤ࡫ࡪ࡙ࡴࡳ࡫ࡱ࡫ࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࡾࠌࠣࠤࠥࠦࠢࠣࠤࡆ")
    error_response_obj = {error_http_status_key: http_status_code, error_detail_message_key: detail_message}
    if error_code_str is not None:
        error_response_obj[error_error_code_key] = error_code_str
    if error_message is not None:
        error_response_obj[error_error_message_key] = error_message
    return error_response_obj