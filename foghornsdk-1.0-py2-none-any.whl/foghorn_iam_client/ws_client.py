# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l1111_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l_opy_ = ord (ll_opy_ [-1])
    l11l1_opy_ = ll_opy_ [:-1]
    l111l_opy_ = l11l_opy_ % len (l11l1_opy_)
    l111_opy_ = l11l1_opy_ [:l111l_opy_] + l11l1_opy_ [l111l_opy_:]
    if l1_opy_:
        l1l1_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1lll_opy_ + l11l_opy_) % l1111_opy_) for l1lll_opy_, char in enumerate (l111_opy_)])
    else:
        l1l1_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1lll_opy_ + l11l_opy_) % l1111_opy_) for l1lll_opy_, char in enumerate (l111_opy_)])
    return eval (l1l1_opy_)
import json
import logging
import websocket
from entities import entities_util
from ws_exception import WSResponseException
logger = logging.getLogger()
ws_get_user_token_command = l1l1l_opy_ (u"ࠤࡪࡩࡹ࡛ࡳࡦࡴࡗࡳࡰ࡫࡮ࠣࠚ")
ws_get_app_token_command = l1l1l_opy_ (u"ࠥ࡫ࡪࡺࡁࡱࡲࡗࡳࡰ࡫࡮ࠣࠛ")
ws_refresh_user_token_command = l1l1l_opy_ (u"ࠦࡷ࡫ࡦࡳࡧࡶ࡬࡚ࡹࡥࡳࡖࡲ࡯ࡪࡴࠢࠜ")
ws_request_id_key = l1l1l_opy_ (u"ࠧࡸࡥࡲࠤࠝ")
ws_command_key = l1l1l_opy_ (u"ࠨࡣ࡮ࡦࠥࠞ")
ws_args_key = l1l1l_opy_ (u"ࠢࡢࡴࡪࡷࠧࠟ")
ws_response_id_key = l1l1l_opy_ (u"ࠣࡴࡨࡷࡵࠨࠠ")
ws_response_obj_key = l1l1l_opy_ (u"ࠤࡵࡩࡹࠨࠡ")
ws_response_err_key = l1l1l_opy_ (u"ࠥࡩࡷࡸࠢࠢ")
def get_connect_url(hostname, port):
    l1l1l_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࡀࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࡷࡳࠥࡻࡳࡦࠢࡩࡳࡷࠦࡣࡰࡰࡶࡸࡷࡻࡣࡵ࡫ࡱ࡫ࠥࡺࡨࡦࠢࡺࡩࡧࡹ࡯ࡤ࡭ࡨࡸࠥࡻࡲ࡭ࠢࡶࡸࡷ࡯࡮ࡨࠌࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡰࡰࡴࡷ࠾ࠥࡶ࡯ࡳࡶࠣࡸࡴࠦࡵࡴࡧࠣࡪࡴࡸࠠࡤࡱࡱࡷࡹࡸࡵࡤࡶ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡻࡪࡨࡳࡰࡥ࡮ࡩࡹࠦࡵࡳ࡮ࠣࡷࡹࡸࡩ࡯ࡩࠍࠤࠥࠦࠠ࠻ࡴࡷࡽࡵ࡫࠺ࠡࡹࡨࡦࠥࡹ࡯ࡤ࡭ࡨࡸࠥࡻࡲ࡭ࠢࡶࡸࡷ࡯࡮ࡨࠢࡦࡳࡳࡹࡴࡳࡷࡦࡸࡪࡪࠠࡶࡵ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡴࡷࡵࡶࡪࡦࡨࡨࠥࡶࡡࡳࡣࡰࡩࡹ࡫ࡲࡴࠌࠣࠤࠥࠦࠢࠣࠤࠣ")
    final_url = l1l1l_opy_ (u"ࠧࡽࡳ࠻࠱࠲ࠦࠤ") + hostname + l1l1l_opy_ (u"ࠨ࠺ࠣࠥ") + port
    return final_url
def create_request(request_counter, command, **args):
    l1l1l_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡄࡴࡨࡥࡹ࡫ࡳࠡࡶ࡫ࡩࠥࡸࡥࡲࡷࡨࡷࡹࠦ࡯ࡣ࡬ࡨࡧࡹࠦࡷࡩ࡫ࡦ࡬ࠥ࡯ࡳࠡࡵࡨࡲࡹࠦ࡯ࡷࡧࡵࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡹ࡯ࡤ࡭ࡨࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯࠰ࠍࠎࠥࠦࠠࠡ࠼ࡷࡽࡵ࡫ࠠࡳࡧࡴࡹࡪࡹࡴࡠࡥࡲࡹࡳࡺࡥࡳ࠼ࠣ࡭ࡳࡺࠠࡵࡻࡳࡩࠥࡼࡡ࡭ࡷࡨࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡴࡨࡵࡺ࡫ࡳࡵࡡࡦࡳࡺࡴࡴࡦࡴ࠽ࠤࡹ࡮ࡥࠡࡷࡱ࡭ࡶࡻࡥࠡ࡫ࡱࡸࡪ࡭ࡥࡳࠢࡵࡩࡵࡸࡥࡴࡧࡱࡸ࡮ࡴࡧࠡࡶ࡫ࡩࠥࡸࡥࡲࡷࡨࡷࡹࠐࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠥࡩ࡯࡮࡯ࡤࡲࡩࠦࡶࡢ࡮ࡸࡩࠏࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡤࡶ࡬ࡹ࠺ࠡࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠤࡴࡨࡪࡦࡥࡷࠤࡦࡹࠠࡱࡣࡵࡸࠥࡵࡦࠡࡶ࡫ࡩࠥࡸࡥࡲࡷࡨࡷࡹࠐࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠥࠦࠧࠦ")
    request_obj = {ws_request_id_key: request_counter, ws_command_key: command, ws_args_key: args}
    return request_obj
def get_response(message):
    l1l1l_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡔࡨࡸࡺࡸ࡮ࡴࠢࡷ࡬ࡪࠦࡡࡱࡲࡵࡳࡵࡸࡩࡢࡶࡨࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࡯ࡣࡶࡤ࡭ࡳ࡫ࡤࠡࡨࡵࡳࡲࠦࡴࡩࡧࠣࡻࡪࡨࡳࡰࡥ࡮ࡩࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰ࠱ࠎࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡ࡯ࡨࡷࡸࡧࡧࡦ࠼ࠣࡉࡽࡺࡲࡢࡥࡷࡷࠥࡺࡨࡦࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡴࡨࡪࡦࡥࡷࠤࡴࡸࠠࡵࡪࡨࠤࡪࡸࡲࡰࡴࠣࡳࡧࡰࡥࡤࡶࠣࡪࡷࡵ࡭ࠡࡶ࡫ࡩࠥࡽࡥࡣࠢࡶࡳࡨࡱࡥࡵࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡴࡨࡪࡦࡥࡷࠤࡴࡨࡴࡢ࡫ࡱࡩࡩࠦ࡯ࡷࡧࡵࠎࠥࠦࠠࠡࠢࠣࠤࠥࡺࡨࡦࠢࡺ࡭ࡷ࡫࠮ࠡࡖ࡫ࡩࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡤࠤ࡯ࡹ࡯࡯ࠢࡲࡦ࡯࡫ࡣࡵ࠰ࠍࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮࠻ࠢࡕࡩࡸࡶ࡯࡯ࡵࡨࠤࡴࡨࡪࡦࡥࡷࠤࡴࡨࡴࡢ࡫ࡱࡩࡩࠦࡡࡧࡶࡨࡶࠥࡹࡵࡤࡥࡨࡷࡸ࡬ࡵ࡭ࠢࡳࡶࡴࡩࡥࡴࡵ࡬ࡲ࡬ࠦ࡯ࡧࠢࡵࡩࡶࡻࡥࡴࡶ࠱ࠤࡎ࡬ࠠࡵࡪࡨࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࠦࡣࡰࡰࡷࡥ࡮ࡴࡳࠡࡧࡵࡶࡴࡸࠬࠡࡶ࡫ࡩࡳࠐࠠࠡࠢࠣࠤࠥࠦࠠࡵࡪࡨࠤ࡜࡙ࡒࡦࡵࡳࡳࡳࡹࡥࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡸࠦࡲࡢ࡫ࡶࡩࡩࠦࡷࡪࡶ࡫ࠤࡦࡶࡰࡳࡱࡳࡶ࡮ࡧࡴࡦࠢࡨࡶࡷࡵࡲࠡࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡳࡧࡰࡥࡤࡶ࠱ࠎࠥࠦࠠࠡࠤࠥࠦࠧ")
    message_obj = json.loads(message)
    if ws_response_obj_key in message_obj:
        resp_obj = message_obj[ws_response_obj_key]
        assert isinstance(resp_obj, dict)
        return resp_obj
    elif ws_response_err_key in message_obj:
        err_obj_str = message_obj[ws_response_err_key]
        try:
            err_obj_json = json.loads(err_obj_str)
            raise WSResponseException(err_obj_json[entities_util.error_http_status_key],
                                      l1l1l_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡸࡥࡴࡲࡲࡲࡸ࡫ࠠࡰࡤࡷࡥ࡮ࡴࡥࡥࠢࡲࡲࠥࡽࡥࡣࡵࡲࡧࡰ࡫ࡴࠣࠨ"),
                                      error_response_obj=err_obj_json)
        except ValueError:
            raise WSResponseException(500, err_obj_str)
class WSClient(object):
    def __init__(self):
        self.ws = websocket.WebSocket()
        self.is_connected = False
        self.l1lll1_opy_ = 0
    def connect(self, hostname, port, timeout=5):
        l1l1l_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡐࡲࡨࡲࠥࡺࡨࡦ࡚ࠢࡩࡧࠦࡓࡰࡥ࡮ࡩࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡻ࡮ࡺࡨࠡࡶ࡫ࡩࠥࡶࡲࡰࡸ࡬ࡨࡪࡪࠠࡩࡱࡶࡸࡳࡧ࡭ࡦࠢࡤࡲࡩࠦࡴࡩࡧࠣࡱࡪࡴࡴࡪࡱࡱࡩࡩࠦࡰࡰࡴࡷ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡶࡼࡴࡪࠦࡨࡰࡵࡷࡲࡦࡳࡥ࠻ࠢࡶࡸࡷ࡯࡮ࡨࠢࡷࡽࡵ࡫ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡪࡲࡷࡹࡴࡡ࡮ࡧ࠽ࠤ࡭ࡵࡳࡵࡰࡤࡱࡪࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡷࡦࡤࠣࡷࡴࡩ࡫ࡦࡶࠣࡷࡪࡸࡶࡦࡴࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡵࡵࡲࡵ࠼ࠣࡸ࡭࡫ࠠࡱࡱࡵࡸࠥࡧࡴࠡࡹ࡫࡭ࡨ࡮ࠠࡵࡱࠣࡧࡴࡴ࡮ࡦࡥࡷࠤࡹࡵࠠࡵࡪࡨࠤࡼ࡫ࡢࡴࡱࡦ࡯ࡪࡺࠠࡴࡧࡵࡺࡪࡸࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡶ࡬ࡱࡪࡵࡵࡵ࠼ࠣࡸ࡮ࡳࡥࡰࡷࡷࠤ࡮ࡴࠠࡴࡧࡦࡳࡳࡪࡳࠡࡹ࡫࡭ࡨ࡮ࠠࡤࡱࡱࡲࡪࡩࡴࡪࡰࡪࠤࡹࡵࠠࡵࡪࡨࠤࡸࡵࡣ࡬ࡧࡷࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥࠩ")
        url = get_connect_url(hostname, port)
        self.ws.settimeout(timeout)
        try:
            self.ws.connect(url)
            self.is_connected = True
        except Exception:
            self.is_connected = False
            raise
    def send_message(self, command, credentials, **args):
        l1l1l_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡏࡨࡸ࡭ࡵࡤࠡ࡫ࡶࠤࡺࡹࡥࡥࠢࡷࡳࠥࡹࡥ࡯ࡦࠣࡱࡪࡹࡳࡢࡩࡨࠤࡴࡼࡥࡳࠢࡷ࡬ࡪࠦࡷࡦࡤࠣࡷࡴࡩ࡫ࡦࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴ࠮ࠡࡏࡤ࡯ࡪࠦࡳࡶࡴࡨࠤࡹ࡮ࡥࠡࡹࡨࡦࠥࡹ࡯ࡤ࡭ࡨࡸࠥࡩ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢ࡫ࡥࡸࠦࡢࡦࡧࡱࠎࠥࠦࠠࠡࠢࠣࠤࠥ࡫ࡸࡤ࡮ࡸࡷ࡮ࡼࡥ࡭ࡻࠣࡩࡸࡺࡡࡣ࡮࡬ࡷ࡭࡫ࡤ࠯ࠢࡕࡩࡶࡻࡥࡴࡶࠣࡻ࡮ࡲ࡬ࠡࡰࡲࡸࠥࡨࡥࠡࡵࡨࡲࡹࠦࡩࡧࠢࡷ࡬ࡪࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡨࡴࡴࡴࠡࡧࡻ࡭ࡸࡺ࠮ࠋࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡴࡳ࡭ࡢࡰࡧ࠾ࠥࡩ࡯࡮࡯ࡤࡲࡩࠦࡴࡰࠢࡸࡷࡪࠦࡦࡰࡴࠣࡱࡦࡱࡩ࡯ࡩࠣࡸ࡭࡫ࠠࡳࡧࡴࡹࡪࡹࡴࠡࡱࡱࠤࡼ࡫ࡢࠡࡵࡲࡧࡰ࡫ࡴ࠯ࠢࡗ࡬ࡪࠦࡣࡰ࡯ࡰࡥࡳࡪࠠ࡮ࡷࡶࡸࠥࡨࡥࠡࡱࡩࠤࡹ࡮ࡥࠡࡶࡼࡴࡪࠦࡤࡦࡨ࡬ࡲࡪࡪࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡶࡡࡤ࡭ࡤ࡫ࡪ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡳࡥࡷࡧ࡭ࠡࡥࡵࡩࡩ࡫࡮ࡵ࡫ࡤࡰࡸࡀࠠࡤࡴࡨࡨࡪࡴࡴࡪࡣ࡯ࡷࠥࡵࡢ࡫ࡧࡦࡸࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡡࡳࡩࡶ࠾ࠥࡺࡨࡦࠢࡤࡨࡩ࡯ࡴࡪࡱࡱࡥࡱࠦࡰࡢࡴࡤࡱࡪࡺࡥࡳࡵࠣ࡯ࡪࡿࠠࡵࡪࡤࡸࠥࡹࡨࡰࡷ࡯ࡨࠥࡨࡥࠡࡣࡧࡨࡪࡪࠠࡪࡰࠣࡸ࡭࡫ࠠࡳࡧࡴࡹࡪࡹࡴࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣࠪ")
        if self.is_connected is True:
            self.l1lll1_opy_ += 1
            scheme = args[l1l1l_opy_ (u"ࠧࡧࡵࡵࡪࡖࡧ࡭࡫࡭ࡦࠤࠫ")]
            request = create_request(self.l1lll1_opy_, command, credentials=credentials,
                                     l1llll_opy_=scheme)
            request_json = json.dumps(request)
            logger.debug(l1l1l_opy_ (u"ࠨࡒࡦࡳࡸࡩࡸࡺࠠࡣࡧ࡬ࡲ࡬ࠦ࡭ࡢࡦࡨࠤ࡮ࡹࠠ࠻ࠢࠥࠬ") + request_json)
            self.ws.send(request_json)
    def recieve_message(self):
        l1l1l_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡋ࡫ࡴࡤࡪࡨࡷࠥࡺࡨࡦࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࠤ࡫ࡸ࡯࡮ࠢࡷ࡬ࡪࠦࡷࡦࡤࠣࡷࡴࡩ࡫ࡦࡶ࠱ࠤ࡙࡮ࡲࡰࡹࡶࠤ࡜࡙ࡒࡦࡵࡳࡳࡳࡹࡥࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭࡫ࠦࡴࡩࡧࠣࡩࡷࡸ࡯ࡳࠢ࡬ࡷࠥࡵࡢࡵࡣ࡬ࡲࡪࡪࠠࡪࡰࠣࡸ࡭࡫ࠠࡳࡧࡶࡴࡴࡴࡳࡦࠌࠣࠤࠥࠦࠠࠡࠢࠣࡳࡧࡰࡥࡤࡶ࠱ࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡࡶ࡫ࡩࠥࡹࡴࡳ࡫ࡱ࡫ࠥࡪࡡࡵࡣࠣࡳࡧࡺࡡࡪࡰࡨࡨࠥ࡬ࡲࡰ࡯ࠣࡸ࡭࡫ࠠࡸࡧࡥࡷࡴࡩ࡫ࡦࡶ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣ࠭")
        if self.is_connected is True:
            response_data = self.ws.recv()
            response_obj = get_response(response_data)
            return response_obj
        else:
            return None
    def close_connection(self):
        l1l1l_opy_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࠢࠣࠤࠥࡉ࡬ࡰࡵࡨࡷࠥࡺࡨࡦࠢࡺࡩࡧࠦࡳࡰࡥ࡮ࡩࡹࠦࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ࠮")
        self.ws.close()