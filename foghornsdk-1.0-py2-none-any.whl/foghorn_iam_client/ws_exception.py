# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l1111_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l_opy_ = ord (ll_opy_ [-1])
    l11l1_opy_ = ll_opy_ [:-1]
    l111l_opy_ = l11l_opy_ % len (l11l1_opy_)
    l111_opy_ = l11l1_opy_ [:l111l_opy_] + l11l1_opy_ [l111l_opy_:]
    if l1_opy_:
        l1l1_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1lll_opy_ + l11l_opy_) % l1111_opy_) for l1lll_opy_, char in enumerate (l111_opy_)])
    else:
        l1l1_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1lll_opy_ + l11l_opy_) % l1111_opy_) for l1lll_opy_, char in enumerate (l111_opy_)])
    return eval (l1l1_opy_)
from entities import entities_util
l11_opy_ = l1l1l_opy_ (u"ࠦࡪࡸࡲࡰࡴࡢࡧࡴࡪࡥࡠࡵࡷࡶࠧࠀ")
l11ll_opy_ = l1l1l_opy_ (u"ࠧ࡫ࡲࡳࡱࡵࡣࡲ࡫ࡳࡴࡣࡪࡩࠧࠁ")
l1l11_opy_ = l1l1l_opy_ (u"ࠨࡥࡳࡴࡲࡶࡤࡸࡥࡴࡲࡲࡲࡸ࡫࡟ࡰࡤ࡭ࠦࠂ")
class WSResponseException(Exception):
    l1l1l_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡶࡦ࡯ࡳࡦࡦࠣࡻ࡭࡫࡮ࠡࡶ࡫ࡩࠥ࡫ࡲࡳࡱࡵࠤ࡮ࡹࠠࡰࡤࡷࡥ࡮ࡴࡥࡥࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࠦࡳࡰࡥ࡮ࡩࡹࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡࡱࡥ࡮ࡪࡩࡴ࠯ࠢࡌࡸࠥࡽࡲࡢࡲࡶࠤࡹ࡮ࡥࠡ࡫ࡰࡴࡴࡸࡴࡢࡰࡷࠤ࡮ࡴࡦࡰࡴࡰࡥࡹ࡯࡯࡯ࠌࠣࠤࠥࠦࡷࡩ࡫ࡦ࡬ࠥࡩࡡ࡯ࠢࡸࡷࡪࡪࠠࡵࡱࠣࡸࡦࡱࡥࠡࡣࡳࡴࡷࡵࡰࡳ࡫ࡤࡸࡪࠦࡡࡤࡶ࡬ࡳࡳࠦࡢࡺࠢࡷ࡬ࡪࠦࡣ࡭࡫ࡨࡲࡹࡹࠠࡶࡵ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡰ࡮ࡨࡲࡢࡴࡼࠤࡧࡿࠠࡦࡺࡷࡶࡦࡩࡴࡪࡰࡪࠤࡹ࡮ࡥࠡࡧࡵࡶࡴࡸ࡟ࡳࡧࡶࡴࡴࡴࡳࡦࠢࡲࡦ࡯࡫ࡣࡵ࠰ࠍࠤࠥࠦࠠࠣࠤࠥࠃ")
    def __init__(self, http_status_code, message, **additional_info):
        l1l1l_opy_ (u"ࠣࠤࠥࠎࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡶࡼࡴࡪࡀࠠࡘࡕࡕࡩࡸࡶ࡯࡯ࡵࡨࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦ࡯ࡣ࡬ࡨࡧࡹࠦࡩ࡯ࡵࡷࡥࡳࡩࡥࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡫ࡸࡹࡶ࡟ࡴࡶࡤࡸࡺࡹ࡟ࡤࡱࡧࡩ࠿ࠦࡨࡵࡶࡳࠤࡸࡺࡡࡵࡷࡶࠤࡨࡵࡤࡦࠢ࡬ࡲࡹ࡫ࡧࡦࡴࠣࡸࡾࡶࡥࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡰࡩࡸࡹࡡࡨࡧ࠽ࠤࡲ࡫ࡳࡴࡣࡪࡩࠥࡺ࡯ࠡࡲࡸࡸࠥࡧࡳࠡࡲࡤࡶࡹࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡤࡲࡩࠦࡴࡩࡧࠣࡩࡷࡸ࡯ࡳࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡧࡤࡥ࡫ࡷ࡭ࡴࡴࡡ࡭ࡡ࡬ࡲ࡫ࡵ࠺ࠡࡖ࡫ࡩࠥࡧࡤࡥ࡫ࡷ࡭ࡴࡴࡡ࡭ࠢ࡬ࡲ࡫ࡵࡲ࡮ࡣࡷ࡭ࡴࡴࠠࡤࡣࡱࠤࡨࡵ࡮ࡵࡣ࡬ࡲࠥࡺࡨࡦࠢࠥࡩࡷࡸ࡯ࡳࡡࡦࡳࡩ࡫࡟ࡴࡶࡵࠦ࠱ࠦࠢࡦࡴࡵࡳࡷࡥ࡭ࡦࡵࡶࡥ࡬࡫ࠢࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࡯ࡳࠢࠥࡩࡷࡸ࡯ࡳࡡࡵࡩࡸࡶ࡯࡯ࡵࡨࡣࡴࡨࡪࠣࠢࡷࡳࠥࡶࡲࡰࡸ࡬ࡨࡪࠦ࡭ࡰࡴࡨࠤ࡮ࡴࡦࡰࡴࡰࡥࡹ࡯࡯࡯ࠢࡲࡲࠥࡺࡨࡦࠢࡨࡶࡷࡵࡲࠡࡴࡤ࡭ࡸ࡫ࡤࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣࠄ")
        Exception.__init__(self, message)
        if additional_info is not None and len(additional_info) > 0:
            if l1l11_opy_ in additional_info:
                self.l1ll1_opy_ = additional_info[l1l11_opy_]
            else:
                self.l1ll1_opy_ = entities_util.get_error_response_obj(http_status_code, message, additional_info)
        else:
            self.l1ll1_opy_ = entities_util.get_error_response_obj(http_status_code, message)
    @property
    def get_error_response(self):
        l1l1l_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࠣࠤࠥࠦࡒࡦࡶࡸࡶࡳࡹࠠࡵࡪࡨࠤࡊࡸࡲࡰࡴࠣࡖࡪࡹࡰࡰࡰࡶࡩࠥࡵࡢ࡫ࡧࡦࡸࠥࡽࡨࡪࡥ࡫ࠤࡨࡵ࡮ࡵࡣ࡬ࡲࡸࠦ࡭ࡰࡴࡨࠤ࡮ࡴࡦࡰࡴࡰࡥࡹ࡯࡯࡯ࠢࡲࡲࠥࡽࡨࡢࡶࠣࡩࡷࡸ࡯ࡳࠢ࡫ࡥࡵࡶࡥ࡯ࡧࡧࠤ࡮ࡴࠠࡵࡪࡨࠤࡷ࡫ࡱࡶࡧࡶࡸࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮࠻ࠢࡈࡶࡷࡵࡲࠡࡔࡨࡷࡵࡵ࡮ࡴࡧࠣࡳࡧࡰࡥࡤࡶࠣࡻ࡭࡯ࡣࡩࠢࡦࡳࡳࡺࡡࡪࡰࡶࠤࡺࡹࡥࡧࡷ࡯ࠤ࡮ࡴࡦࡰࡴࡰࡥࡹ࡯࡯࡯ࠢࡲࡲࠥࡺࡨࡦࠢࡨࡶࡷࡵࡲ࠯ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨࠅ")
        return self.l1ll1_opy_