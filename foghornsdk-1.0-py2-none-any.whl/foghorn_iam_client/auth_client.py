# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l1111_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l_opy_ = ord (ll_opy_ [-1])
    l11l1_opy_ = ll_opy_ [:-1]
    l111l_opy_ = l11l_opy_ % len (l11l1_opy_)
    l111_opy_ = l11l1_opy_ [:l111l_opy_] + l11l1_opy_ [l111l_opy_:]
    if l1_opy_:
        l1l1_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1lll_opy_ + l11l_opy_) % l1111_opy_) for l1lll_opy_, char in enumerate (l111_opy_)])
    else:
        l1l1_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1lll_opy_ + l11l_opy_) % l1111_opy_) for l1lll_opy_, char in enumerate (l111_opy_)])
    return eval (l1l1_opy_)
import logging
import ws_client
from entities import entities_util
from ws_client import WSClient
logger = logging.getLogger()
class AuthClient:
    l1l1l_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࡘ࡭࡫ࠠࡤ࡮ࡤࡷࡸࠦࡩ࡮ࡲ࡯ࡩࡲ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡸࡪ࡬ࡧ࡭ࠦࡰࡳࡱࡹ࡭ࡩ࡫ࡳࠡࡵࡸࡴࡵࡵࡲࡵࠢࡩࡳࡷࠦࡦࡦࡶࡦ࡬࡮ࡴࡧࠡࡰࡨࡻࠥࡧࡣࡤࡧࡶࡷࠥࡺ࡯࡬ࡧࡱࠤ࡫ࡵࡲࠡࡶ࡫ࡩࠥࡻࡳࡦࡴ࠯ࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࡵ࠱ࠤࡆࡲࡳࡰࠌࠣࠤࠥࠦࡳࡶࡲࡳࡳࡷࡺࡳࠡࡴࡨࡪࡷ࡫ࡳࡩ࡫ࡱ࡫ࠥࡧࡣࡤࡧࡶࡷࠥࡺ࡯࡬ࡧࡱࡷࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡵࡴࡧࡵࡷ࠳ࠦࡔࡩࡧࠣࡧࡱࡧࡳࡴࠢࡦࡶࡪࡧࡴࡦࡵࠣࡸ࡭࡫ࠠࡸࡧࡥࡷࡴࡩ࡫ࡦࡶࠣࡧࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠠࡧࡱࡵࠤࡹ࡮ࡥࠡࡴࡨࡵࡺ࡫ࡳࡵ࠮ࠍࠤࠥࠦࠠࡢࡰࡧࠤࡨࡲ࡯ࡴࡧࡶࠤࡹ࡮ࡥࠡࡥࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥࡵ࡮ࡤࡧࠣࡸ࡭࡫ࠠࡳࡧࡶࡴࡴࡴࡳࡦࠢ࡬ࡷࠥࡵࡢࡵࡣ࡬ࡲࡪࡪ࠮ࠋࠢࠣࠤࠥࠨࠢࠣࠆ")
    def __init__(self, hostname, port):
        if not (hostname is None and hostname.strip()):
            self.hostname = hostname
            self.port = port
            self.client = WSClient()
    def get_user_token(self, username, password, client_id, client_secret):
        l1l1l_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡈࡨࡸࡨ࡮ࡥࡴࠢࡤࡧࡨ࡫ࡳࡴࠢࡷࡳࡰ࡫࡮ࠡࡱࡱࠤࡧ࡫ࡨࡢ࡮ࡩࠤࡴ࡬ࠠࡵࡪࡨࠤࡺࡹࡥࡳ࠰ࠣࡖࡪࡺࡵࡳࡰࡶࠤࡦࡶࡰࡳࡱࡳࡶ࡮ࡧࡴࡦࠢࡶࡹࡨࡩࡥࡴࡵࡩࡹࡱࠦࡲࡦࡵࡳࡳࡳࡹࡥࠡࡱࡵࠤࡹ࡮ࡲࡰࡹࡶࠤࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠊࠡࠢࠣࠤࠥࠦࠠࠡ࡫ࡱࠤࡨࡧࡳࡦࠢࡷ࡬ࡪࡸࡥࠡ࡫ࡶࠤࡪࡸࡲࡰࡴࠣ࡭ࡳࠦࡴࡩࡧࠣࡶࡪࡷࡵࡦࡵࡷࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡻࡳࡦࡴࡱࡥࡲ࡫࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡳࡥࡸࡹࡷࡰࡴࡧ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡣ࡭࡫ࡨࡲࡹࡥࡩࡥ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡨࡲࡩࡦࡰࡷࡣࡸ࡫ࡣࡳࡧࡷ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠡࡃࡦࡧࡪࡹࡳࠡࡶࡲ࡯ࡪࡴࠠࡰࡤ࡭ࡩࡨࡺࠠࡰࡤࡷࡥ࡮ࡴࡥࡥࠢࡩࡶࡴࡳࠠࡵࡪࡨࠤࡷ࡫ࡱࡶࡧࡶࡸࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡶࡼࡴࡪࡀࠠࡶࡵࡨࡶࠥࡺ࡯࡬ࡧࡱࠤ࡮࡬ࠠࡰࡲࡨࡶࡦࡺࡩࡰࡰࠣ࡭ࡸࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮࠯ࠤࡳࡵ࡮ࡦࠢࡲࡸ࡭࡫ࡲࡸ࡫ࡶࡩࠥࡵࡲࠡࡧࡻࡧࡪࡶࡴࡪࡱࡱࠤࡹ࡮ࡲࡰࡹࡱࠎࠥࠦࠠࠡࠢࠣࠤࠥࠨࠢࠣࠇ")
        creds_dict = entities_util.get_credentials_obj(username, password, client_id, client_secret)
        logger.debug(l1l1l_opy_ (u"ࠧࡉࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠣࡧࡷ࡫ࡡࡵࡧࡧࠤࡦࡸࡥࠡ࠼ࠣࠦࠈ") + str(creds_dict))
        try:
            self.client.connect(self.hostname, self.port)
            self.client.send_message(ws_client.ws_get_user_token_command, creds_dict, l1llll_opy_=l1l1l_opy_ (u"ࠨ࡯ࡢࡷࡷ࡬࠷ࠨࠉ"))
            logger.debug(l1l1l_opy_ (u"ࠢࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡷࡦࡤࡶࡳࡨࡱࡥࡵ࠮ࠣࡲࡴࡽࠠࡸࡣ࡬ࡸ࡮ࡴࡧࠡࡨࡲࡶࠥࡺࡨࡦࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࠦࠊ"))
            response = self.client.recieve_message()
            logger.debug(l1l1l_opy_ (u"ࠣࡏࡨࡷࡸࡧࡧࡦࠢࡵࡩࡨ࡫ࡩࡷࡧࡧࠤࡴࡴࠠࡵࡪࡨࠤࡼ࡫ࡢࡴࡱࡦ࡯ࡪࡺࠠࡪࡵ࠽ࠤࠧࠋ") + str(response))
        finally:
            self.client.close_connection()
        return response
    def get_app_token(self, client_id, client_secret):
        l1l1l_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࠣࠤࠥࠦࡆࡦࡶࡦ࡬ࡪࡹࠠࡵࡪࡨࠤࡦࡩࡣࡦࡵࡶࠤࡹࡵ࡫ࡦࡰࠣࡳࡳࠦࡢࡦࡪࡤࡰ࡫ࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠲ࠥࡘࡥࡵࡷࡵࡲࡸࠦࡴࡩࡧࠣࡥࡵࡶࡲࡰࡲࡵ࡭ࡦࡺࡥࠡࡴࡨࡷࡵࡵ࡮ࡴࡧࠣࡦࡦࡩ࡫ࠡࡱࡵࠤࡹ࡮ࡲࡰࡹࡶࠤࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠊࠡࠢࠣࠤࠥࠦࠠࠡ࡫ࡱࠤࡨࡧࡳࡦࠢࡷ࡬ࡪࡸࡥࠡ࡫ࡶࠤࡦࡴࠠࡦࡴࡵࡳࡷࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡲࡦࡳࡸࡩࡸࡺࠊࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡦࡰ࡮࡫࡮ࡵࡡ࡬ࡨ࠿ࠦࡣ࡭࡫ࡨࡲࡹࡏࡤࠡࡲࡵࡳࡵ࡫ࡲࡵࡻࠣࡪࡴࡸࠠࡵࡪࡨࠤࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡵࡧࡲࡢ࡯ࠣࡧࡱ࡯ࡥ࡯ࡶࡢࡷࡪࡩࡲࡦࡶ࠽ࠤࡨࡲࡩࡦࡰࡷࡗࡪࡩࡲࡦࡶࠣࡴࡷࡵࡰࡦࡴࡷࡽࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡀࠊࠡࠢࠣࠤࠥࠦࠠࠡࠤࠥࠦࠌ")
        creds_dict = entities_util.get_credentials_obj(None, None, client_id, client_secret)
        logger.debug(l1l1l_opy_ (u"ࠥࡇࡷ࡫ࡤࡦࡰࡷ࡭ࡦࡲࡳࠡࡅࡵࡩࡦࡺࡥࡥࠢࡤࡶࡪࠦ࠺ࠡࠤࠍ") + str(creds_dict))
        try:
            self.client.connect(self.hostname, self.port)
            self.client.send_message(ws_client.ws_get_app_token_command, creds_dict, l1llll_opy_=l1l1l_opy_ (u"ࠦࡴࡧࡵࡵࡪ࠵ࠦࠎ"))
            logger.debug(l1l1l_opy_ (u"ࠧࡓࡥࡴࡵࡤ࡫ࡪࠦࡳࡦࡰࡷࠤࡴࡴࠠࡵࡪࡨࠤࡼ࡫ࡢࡴࡱࡦ࡯ࡪࡺࠬࠡࡰࡲࡻࠥࡽࡡࡪࡶ࡬ࡲ࡬ࠦࡦࡰࡴࠣࡸ࡭࡫ࠠࡳࡧࡶࡴࡴࡴࡳࡦࠤࠏ"))
            response = self.client.recieve_message()
            logger.debug(l1l1l_opy_ (u"ࠨࡍࡦࡵࡶࡥ࡬࡫ࠠࡳࡧࡦࡩ࡮ࡼࡥࡥࠢࡲࡲࠥࡺࡨࡦࠢࡺࡩࡧࡹ࡯ࡤ࡭ࡨࡸࠥ࡯ࡳ࠻ࠢࠥࠐ") + str(response))
        finally:
            self.client.close_connection()
        return response
    def refresh_user_token(self, username, password, client_id, client_secret, access_token):
        l1l1l_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡗ࡫ࡦࡳࡧࡶ࡬ࡪࡹࠠࡵࡪࡨࠤࡦࡩࡣࡦࡵࡶࠤࡹࡵ࡫ࡦࡰࠣࡪࡴࡸࠠࡵࡪࡨࠤࡺࡹࡥࡳ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡻࡳࡦࡴࡱࡥࡲ࡫࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡳࡥࡸࡹࡷࡰࡴࡧ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡣ࡭࡫ࡨࡲࡹࡥࡩࡥ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡨࡲࡩࡦࡰࡷࡣࡸ࡫ࡣࡳࡧࡷ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡱࡣࡵࡥࡲࠦࡡࡤࡥࡨࡷࡸࡥࡴࡰ࡭ࡨࡲ࠿ࠦࡴࡩ࡫ࡶࠤࡴࡨࡪࡦࡥࡷࠤࡸ࡮࡯ࡶ࡮ࡧࠤࡧ࡫ࠠࡰࡨࠣࡨ࡮ࡩࡴࡪࡱࡱࡥࡷࡿࠠࡵࡻࡳࡩࠥ࡯࡮ࠡࡶ࡫ࡩࠥ࡬࡯࡭࡮ࡲࡻ࡮ࡴࡧࠡࡨࡲࡶࡲࡧࡴ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡼࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠧࡺ࡯࡬ࡧࡱࠦࠥࡀࠠ࠽ࡸࡤࡰࡺ࡫࠾࠭ࠢࠥࡸࡾࡶࡥࠣࠢ࠽ࠤࡁࡺࡹࡱࡧ࡙ࡥࡱࡻࡥ࠿࠮ࠣࠦࡪࡾࡰࡕ࡫ࡰࡩࠧࠦ࠺ࠡ࠴࠼࠸࠷࠲ࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡶࡪ࡬ࡲࡦࡵ࡫ࡘࡴࡱࡥ࡯ࠤࠣ࠾ࠥࡂࡲࡦࡨࡵࡩࡸ࡮ࡔࡰ࡭ࡨࡲ࡛ࡧ࡬ࡶࡧࡁ࠰ࠥࠨࡳࡤࡱࡳࡩࠧࠦ࠺ࠡ࡝ࠣࡀࡸ࠷࠾࠭ࠢ࠿ࡷ࠷ࡄࠠ࡞࠮ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠨࡡࡥࡦ࡬ࡸ࡮ࡵ࡮ࡢ࡮ࡌࡲ࡫ࡵࠢࠡ࠼ࠣࡿࠥࡂ࡫ࡦࡻ࠴ࡂࠥࡀࠠ࠽ࡸࡤࡰࡺ࡫࠱࠿࠮ࠣࡀࡰ࡫ࡹ࠳ࡀࠣ࠾ࠥࡂࡶࡢ࡮ࡸࡩ࠷ࡄࠠࡾࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡾࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠾ࡷ࡫ࡴࡶࡴࡱ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤࠑ")
        token_value, exp_time, token_type, refresh_token, scope, addl_info = l1l1l_opy_ (u"ࠣࠤࠒ"), 0, l1l1l_opy_ (u"ࠤࡥࡩࡦࡸࡥࡳࠤࠓ"), l1l1l_opy_ (u"ࠥࠦࠔ"), None, None
        if entities_util.accesstoken_token_value_key in access_token:
            token_value = access_token[entities_util.accesstoken_token_value_key]
        if entities_util.accesstoken_exp_time_key in access_token:
            exp_time = access_token[entities_util.accesstoken_exp_time_key]
        if entities_util.accesstoken_refresh_token_key in access_token:
            refresh_token = access_token[entities_util.accesstoken_refresh_token_key]
        if entities_util.accesstoken_token_type_key in access_token:
            token_type = access_token[entities_util.accesstoken_token_type_key]
        if entities_util.accesstoken_scope_key in access_token:
            scope = access_token[entities_util.accesstoken_scope_key]
        if entities_util.accesstoken_addl_info_key in access_token:
            addl_info = access_token[entities_util.accesstoken_addl_info_key]
        access_token_dict = entities_util.get_access_token_obj(token_value, exp_time, token_type,
                                                               refresh_token, scope, addl_info)
        logger.debug(l1l1l_opy_ (u"ࠦࡆࡩࡣࡦࡵࡶࠤࡹࡵ࡫ࡦࡰࠣࡳࡧࡰࡥࡤࡶࠣࡳࡧࡺࡡࡪࡰࡨࡨࠥ࡯ࡳࠡ࠼ࠣࠦࠕ") + str(access_token_dict))
        creds_dict = entities_util.get_credentials_obj(username, password, client_id, client_secret, access_token_dict)
        logger.debug(l1l1l_opy_ (u"ࠧࡉࡲࡦࡦࡨࡲࡹ࡯ࡡ࡭ࡵࠣࡳࡧࡰࡥࡤࡶࠣࡳࡧࡺࡡࡪࡰࡨࡨࠥ࡯ࡳࠡ࠼ࠣࠦࠖ") + str(creds_dict))
        try:
            self.client.connect(self.hostname, self.port)
            self.client.send_message(ws_client.ws_refresh_user_token_command, creds_dict, l1llll_opy_=l1l1l_opy_ (u"ࠨ࡯ࡢࡷࡷ࡬࠷ࠨࠗ"))
            logger.debug(l1l1l_opy_ (u"ࠢࡎࡧࡶࡷࡦ࡭ࡥࠡࡵࡨࡲࡹࠦ࡯࡯ࠢࡷ࡬ࡪࠦࡷࡦࡤࡶࡳࡨࡱࡥࡵ࠮ࠣࡲࡴࡽࠠࡸࡣ࡬ࡸ࡮ࡴࡧࠡࡨࡲࡶࠥࡺࡨࡦࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࠦ࠘"))
            response = self.client.recieve_message()
            logger.debug(l1l1l_opy_ (u"ࠣࡏࡨࡷࡸࡧࡧࡦࠢࡵࡩࡨ࡫ࡩࡷࡧࡧࠤࡴࡴࠠࡵࡪࡨࠤࡼ࡫ࡢࡴࡱࡦ࡯ࡪࡺࠠࡪࡵ࠽ࠤࠧ࠙") + response)
        finally:
            self.client.close_connection()
        return response