# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l11_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l1_opy_ = ord (ll_opy_ [-1])
    l1111_opy_ = ll_opy_ [:-1]
    l111_opy_ = l11l1_opy_ % len (l1111_opy_)
    l1lll_opy_ = l1111_opy_ [:l111_opy_] + l1111_opy_ [l111_opy_:]
    if l1_opy_:
        l11l_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    else:
        l11l_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    return eval (l11l_opy_)
import json
class SystemEvent(object):
    l1ll111_opy_ 		= l1l1l_opy_ (u"ࠧࡴࡥࡸࡡࡷࡳࡵ࡯ࡣࠣࡸ")
    l11111_opy_ 		= l1l1l_opy_ (u"ࠨࡥࡥ࡫ࡷࡣࡹࡵࡰࡪࡥࠥࡹ")
    l1ll1ll_opy_ 	= l1l1l_opy_ (u"ࠢࡥࡧ࡯ࡩࡹ࡫࡟ࡵࡱࡳ࡭ࡨࠨࡺ")
    l1lll11_opy_ 	= l1l1l_opy_ (u"ࠣࡰࡨࡻࡤࡪࡥࡤࡱࡧࡩࡷࠨࡻ")
    l1ll1l1_opy_ 	= l1l1l_opy_ (u"ࠤࡨࡨ࡮ࡺ࡟ࡥࡧࡦࡳࡩ࡫ࡲࠣࡼ")
    l1l1ll1_opy_ 	= l1l1l_opy_ (u"ࠥࡨࡪࡲࡥࡵࡧࡢࡨࡪࡩ࡯ࡥࡧࡵࠦࡽ")
    l1l1lll_opy_ 	= l1l1l_opy_ (u"ࠦࡳ࡫ࡷࡠ࡮࡬ࡦࡷࡧࡲࡺࠤࡾ")
    l1lll1l_opy_ 	= l1l1l_opy_ (u"ࠧ࡫ࡤࡪࡶࡢࡰ࡮ࡨࡲࡢࡴࡼࠦࡿ")
    l1lllll_opy_ 	= l1l1l_opy_ (u"ࠨࡤࡦ࡮ࡨࡸࡪࡥ࡬ࡪࡤࡵࡥࡷࡿࠢࢀ")
    l1ll11l_opy_      = l1l1l_opy_ (u"ࠢࡤࡱࡱࡪ࡮࡭ࠢࢁ")
    SENSOR_REFRESH  = l1l1l_opy_ (u"ࠣࡵࡨࡲࡸࡵࡲࡠࡴࡨࡪࡷ࡫ࡳࡩࠤࢂ")
    def __init__(self, type, id, data=None):
        self.type = type
        self.id = id
        self.data = data
    def get_type(self):
        return self.type
    def get_id(self):
        return self.id
    def get_data(self):
        return self.data
    def to_json(self):
        return json.dump(self.__dict__)
    @classmethod
    def from_json(cls, json_str):
        l1llll1_opy_ = json.loads(json_str)
        return cls(**l1llll1_opy_)