# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l11_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l1_opy_ = ord (ll_opy_ [-1])
    l1111_opy_ = ll_opy_ [:-1]
    l111_opy_ = l11l1_opy_ % len (l1111_opy_)
    l1lll_opy_ = l1111_opy_ [:l111_opy_] + l1111_opy_ [l111_opy_:]
    if l1_opy_:
        l11l_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    else:
        l11l_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    return eval (l11l_opy_)
from influxdb import InfluxDBClient
from cmd_option import CommandOptions
class TimeSeriesDatabase(InfluxDBClient):
    def __init__(self, username, password, logger, config_mgr):
        super(TimeSeriesDatabase, self).__init__(host=CommandOptions.DBASE_HOST, port=CommandOptions.DBASE_PORT, username=username, password=password)
        self.__logger = logger
        self.__1l111_opy_ = config_mgr
    def get_list_measurements(self, database=None):
        measurements = []
        try:
            response = self.query(l1l1l_opy_ (u"ࠤࡖࡌࡔ࡝ࠠࡎࡇࡄࡗ࡚ࡘࡅࡎࡇࡑࡘࡘࠨ࠯"), database=database)
            if response.error is None:
                if len(response.raw) > 0:
                    series = response.raw[l1l1l_opy_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ࠰")][0]
                    values = series[l1l1l_opy_ (u"ࠫࡻࡧ࡬ࡶࡧࡶࠫ࠱")]
                    for value in values:
                        measurements.append(value[0])
        except Exception as e:
            self.__logger.log_debug(l1l1l_opy_ (u"࡚ࠧࡩ࡮ࡧࡖࡩࡷ࡯ࡥࡴࡆࡤࡸࡦࡨࡡࡴࡧ࠱࡫ࡪࡺ࡟࡭࡫ࡶࡸࡤࡳࡥࡢࡵࡸࡶࡪࡳࡥ࡯ࡶࡶࠤࡪࡸࡲࡰࡴ࠽ࠤࠧ࠲") + str(e))
        return measurements
    def get_list_fields(self, measurement, dbname=None):
        l1l1l_opy_ (u"ࠨࠢࠣࠌࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡶࡡࡳࡣࡰࠤࡲ࡫ࡡࡴࡷࡵࡩࡲ࡫࡮ࡵ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥ࠳")
        fields = []
        try:
            rsp = self.query(l1l1l_opy_ (u"ࠢࡔࡊࡒ࡛ࠥࡌࡉࡆࡎࡇࠤࡐࡋ࡙ࡔࠢࡉࡖࡔࡓࠠࠣ࠴") + l1l1l_opy_ (u"ࠣ࡞ࠥࠦ࠵") + str(measurement) + l1l1l_opy_ (u"ࠤ࡟ࠦࠧ࠶"), database=dbname)
            if rsp.error is None:
                series = rsp.raw[l1l1l_opy_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ࠷")][0]
                fields = series[l1l1l_opy_ (u"ࠫࡻࡧ࡬ࡶࡧࡶࠫ࠸")]
        except Exception as e:
            self.__logger.log_debug(l1l1l_opy_ (u"࡚ࠧࡩ࡮ࡧࡖࡩࡷ࡯ࡥࡴࡆࡤࡸࡦࡨࡡࡴࡧ࠱࡫ࡪࡺ࡟࡭࡫ࡶࡸࡤࡳࡥࡢࡵࡸࡶࡪࡳࡥ࡯ࡶࡶࠤࡪࡸࡲࡰࡴ࠽ࠤࠧ࠹") + str(e))
        return fields
    def create_database_with_rentention_policy(self, dbname):
        l1l1l_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࠠࠡࠢࠣࡇࡷ࡫ࡡࡵࡧࠣࡥࠥࡪࡡࡵࡣࡥࡥࡸ࡫ࠠࡸ࡫ࡷ࡬ࠥࡸࡥࡵࡧࡱࡸ࡮ࡵ࡮ࠡࡲࡲࡰ࡮ࡩࡹࠡࡦࡨࡪ࡮ࡴࡥࡥࠢ࡬ࡲࠥࡺࡨࡦࠢࡨࡨ࡬࡫ࠠࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡌࡪࠥࡶ࡯࡭࡫ࡦࡽࠥ࡯ࡳࠡࡰࡲࡸࠥ࡬࡯ࡶࡰࡧࠤ࡮ࡴࠠࡵࡪࡨࠤࡨࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱ࠰ࠥ࡯ࡴࠡࡥࡵࡩࡦࡺࡥࡴࠢࡤࠤࡩࡧࡴࡢࡤࡤࡷࡪࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡥࠡࡦࡨࡪࡦࡻ࡬ࡵࠢࡳࡳࡱ࡯ࡣࡺ࠰ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࡙࡮ࡥࠡࡦࡸࡶࡦࡺࡩࡰࡰࠣࡳ࡫ࠦࡰࡰ࡮࡬ࡧࡾࠦࡩࡴࠢࡧࡩ࡫࡯࡮ࡦࡦࠣࡺ࡮ࡧࠠࡵࡪࡨࠤࡪࡪࡧࡦࠢࡰࡥࡳࡧࡧࡦ࡯ࡨࡲࡹࠦࡕࡊ࠰ࠍࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡰࡢࡴࡤࡱࠥࡪࡢ࡯ࡣࡰࡩ࠿ࠦࡩࡴࠢࡷ࡬ࡪࠦࡤࡢࡶࡤࡦࡦࡹࡥࠡࡰࡤࡱࡪࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠻ࡴࡨࡸࡺࡸ࡮࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠦࠧࠨ࠺")
        if self.database_exists(dbname):
            self.__logger.log_debug(l1l1l_opy_ (u"ࠢࡕ࡫ࡰࡩࡘ࡫ࡲࡪࡧࡶࡈࡦࡺࡡࡣࡣࡶࡩ࠳ࡩࡲࡦࡣࡷࡩࡤࡪࡡࡵࡣࡥࡥࡸ࡫࡟ࡸ࡫ࡷ࡬ࡤࡸࡥ࡯ࡶࡨࡲࡹ࡯࡯࡯ࡡࡳࡳࡱ࡯ࡣࡺࠢࡤࡰࡷ࡫ࡡࡥࡻࠣࡩࡽ࡯ࡳࡵࡵ࠽ࠤࠧ࠻") + dbname)
            return
        retention_period = self.__1l111_opy_.get_retention_period()
        if retention_period is not None:
            if l1l1l_opy_ (u"ࠨࡲࡨࡶ࡮ࡵࡤࠨ࠼") in retention_period and l1l1l_opy_ (u"ࠩࡳࡩࡷ࡯࡯ࡥࡖࡼࡴࡪ࠭࠽") in retention_period:
                l11ll1_opy_ = retention_period[l1l1l_opy_ (u"ࠪࡴࡪࡸࡩࡰࡦࠪ࠾")]
                l11lll_opy_ = retention_period[l1l1l_opy_ (u"ࠫࡵ࡫ࡲࡪࡱࡧࡘࡾࡶࡥࠨ࠿")]
                duration = None
                if l11lll_opy_ == l1l1l_opy_ (u"ࠬࡳࡩ࡯ࡷࡷࡩࡸ࠭ࡀ"):
                    duration = str(l11ll1_opy_) + l1l1l_opy_ (u"࠭࡭ࠨࡁ")
                if l11lll_opy_ == l1l1l_opy_ (u"ࠧࡩࡱࡸࡶࡸ࠭ࡂ"):
                    duration = str(l11ll1_opy_) + l1l1l_opy_ (u"ࠨࡪࠪࡃ")
                if l11lll_opy_ == l1l1l_opy_ (u"ࠩࡧࡥࡾࡹࠧࡄ"):
                    duration = str(l11ll1_opy_) + l1l1l_opy_ (u"ࠪࡨࠬࡅ")
                if l11lll_opy_ == l1l1l_opy_ (u"ࠫࡼ࡫ࡥ࡬ࡵࠪࡆ"):
                    duration = str(l11ll1_opy_) + l1l1l_opy_ (u"ࠬࡽࠧࡇ")
                query = l1l1l_opy_ (u"ࠨࡃࡓࡇࡄࡘࡊࠦࡄࡂࡖࡄࡆࡆ࡙ࡅࠡࠤࡈ") + dbname + l1l1l_opy_ (u"࡙ࠢࠡࡌࡘࡍࠦࡄࡖࡔࡄࡘࡎࡕࡎࠡࠤࡉ") + duration + l1l1l_opy_ (u"ࠣࠢࡑࡅࡒࡋࠠࠣࡊ") + l1l1l_opy_ (u"ࠤࡕࡔࡤࠨࡋ") + dbname + l1l1l_opy_ (u"ࠥࡣࠧࡌ") + duration
                self.__logger.log_debug(l1l1l_opy_ (u"࡙ࠦ࡯࡭ࡦࡕࡨࡶ࡮࡫ࡳࡅࡣࡷࡥࡧࡧࡳࡦ࠰ࡦࡶࡪࡧࡴࡦࡡࡧࡥࡹࡧࡢࡢࡵࡨࡣࡼ࡯ࡴࡩࡡࡵࡩࡳࡺࡥ࡯ࡶ࡬ࡳࡳࡥࡰࡰ࡮࡬ࡧࡾࠦࡱࡶࡧࡵࡽࠥࡃࠠࠣࡍ") + query)
                self.query(query)
        else:
            self.create_database(dbname, False)
    def database_exists(self, dbname):
        l11l1l_opy_ = self.get_list_database()
        if l11l1l_opy_ is not None:
            for database in l11l1l_opy_:
                if dbname in database.values():
                    return True
        return False