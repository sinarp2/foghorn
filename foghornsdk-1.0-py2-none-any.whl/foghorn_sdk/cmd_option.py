# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l11_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l1_opy_ = ord (ll_opy_ [-1])
    l1111_opy_ = ll_opy_ [:-1]
    l111_opy_ = l11l1_opy_ % len (l1111_opy_)
    l1lll_opy_ = l1111_opy_ [:l111_opy_] + l1111_opy_ [l111_opy_:]
    if l1_opy_:
        l11l_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    else:
        l11l_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    return eval (l11l_opy_)
import argparse
import os
class CommandOptions(object):
    __1ll1ll1_opy_ = l1l1l_opy_ (u"ࠨ࠱࠳࠹࠱࠴࠳࠶࠮࠲ࠤࢪ")
    EM_HOST = __1ll1ll1_opy_
    EM_PORT = 8001
    DBUS_HOST = __1ll1ll1_opy_
    DBUS_SUB_PORT = 9501
    DBUS_PUB_PORT = 8500
    DBASE_HOST = __1ll1ll1_opy_
    DBASE_PORT = 8086
    AUTH_CLIENT_ID = None
    AUTH_CLIENT_SECRET = None
    AUTH_ACCESS_TOKEN = None
    def __init__(self):
        self.parser = self.get_parse()
        self.parser.add_argument(l1l1l_opy_ (u"ࠢ࠮ࡧࡰ࡬ࡴࡹࡴࠣࢫ"))
        self.parser.add_argument(l1l1l_opy_ (u"ࠣ࠯ࡨࡱࡵࡵࡲࡵࠤࢬ"))
        self.parser.add_argument(l1l1l_opy_ (u"ࠤ࠰ࡨࡧࡻࡳࡩࡱࡶࡸࠧࢭ"))
        self.parser.add_argument(l1l1l_opy_ (u"ࠥ࠱ࡸࡻࡢࡱࡱࡵࡸࠧࢮ"))
        self.parser.add_argument(l1l1l_opy_ (u"ࠦ࠲ࡶࡵࡣࡲࡲࡶࡹࠨࢯ"))
        self.parser.add_argument(l1l1l_opy_ (u"ࠧ࠳ࡤࡣࡣࡶࡩ࡭ࡵࡳࡵࠤࢰ"))
        self.parser.add_argument(l1l1l_opy_ (u"ࠨ࠭ࡥࡤࡤࡷࡪࡶ࡯ࡳࡶࠥࢱ"))
        self.parser.add_argument(l1l1l_opy_ (u"ࠢ࠮ࡣࡸࡸ࡭ࡉ࡬ࡪࡧࡱࡸࡎࡪࠢࢲ"))
        self.parser.add_argument(l1l1l_opy_ (u"ࠣ࠯ࡤࡹࡹ࡮ࡃ࡭࡫ࡨࡲࡹ࡙ࡥࡤࡴࡨࡸࠧࢳ"))
        self.parser.add_argument(l1l1l_opy_ (u"ࠤ࠰ࡥࡺࡺࡨࡂࡥࡦࡩࡸࡹࡔࡰ࡭ࡨࡲࠧࢴ"))
    def add_argument(self, *args, **kwargs):
        l1l1l_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡵࡪ࡬ࡷࠥࡳࡥࡵࡪࡲࡨࠥࡧ࡬࡭ࡱࡺࡷࠥࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࡶࠤࡹࡵࠠࡢࡦࡧࠤࡹ࡮ࡥࡪࡴࠣࡳࡼࡴࠠࡤࡱࡰࡱࡦࡴࡤࠡ࡮࡬ࡲࡪࠦ࡯ࡱࡶ࡬ࡳࡳࡹ࠮ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢࡤࡶ࡬ࡹ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡴࡦࡸࡡ࡮ࠢ࡮ࡻࡦࡸࡧࡴ࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠿ࡸࡥࡵࡷࡵࡲ࠿ࠐࠠࠡࠢࠣࠤࠥࠦࠠࠣࠤࠥࢵ")
        self.parser.add_argument(*args, **kwargs)
    def parse(self):
        l1l1l_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࡈ࡬ࡶࡸࡺࠠࡵࡴ࡬ࡩࡸࠦࡴࡰࠢࡪࡩࡹࠦࡳࡥ࡭ࠣࡴࡷࡵࡰࡦࡴࡷࡽࠥࡼࡡ࡭ࡷࡨࠤ࡫ࡸ࡯࡮ࠢࡤࡲࠥࡕࡓࠡࡧࡱࡺ࡮ࡸ࡯࡯࡯ࡨࡲࡹࠦࡶࡢࡴ࡬ࡥࡧࡲࡥࠡࡣࡱࡨࠥ࡯ࡦࠡࡰࡲࡸࠥ࡬࡯ࡶࡰࡧࠤ࡮ࡺࠠࡸ࡫࡯ࡰࠏࠦࠠࠡࠢࠣࠤࠥࠦࡴࡳࡻࠣࡸࡴࠦࡧࡦࡶࠣ࡭ࡹࠦࡦࡳࡱࡰࠤࡨࡵ࡭࡮ࡣࡱࡨࠥࡲࡩ࡯ࡧࠣࡳࡵࡺࡩࡰࡰࡶ࠲ࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠺ࡳࡧࡷࡹࡷࡴ࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧࢶ")
        args, _ = self.parser.parse_known_args()
        value = os.environ.get(l1l1l_opy_ (u"ࠬࡋࡄࡈࡇࡢࡑࡆࡔࡁࡈࡇࡕࡣࡍࡕࡓࡕࠩࢷ"))
        if value is not None and len(value) > 0:
            CommandOptions.EM_HOST = value
        elif hasattr(args, l1l1l_opy_ (u"࠭ࡥ࡮ࡪࡲࡷࡹ࠭ࢸ")) and args.emhost:
            CommandOptions.EM_HOST = args.emhost
        value = os.environ.get(l1l1l_opy_ (u"ࠧࡆࡆࡊࡉࡤࡓࡁࡏࡃࡊࡉࡗࡥࡐࡐࡔࡗࠫࢹ"))
        if value is not None and len(value) > 0:
            CommandOptions.EM_PORT = value
        elif hasattr(args, l1l1l_opy_ (u"ࠨࡧࡰࡴࡴࡸࡴࠨࢺ")) and args.emport:
            CommandOptions.EM_PORT = args.emport
        value = os.environ.get(l1l1l_opy_ (u"ࠩࡐࡉࡘ࡙ࡁࡈࡇࡢࡆ࡚࡙࡟ࡉࡑࡖࡘࠬࢻ"))
        if value is not None and len(value) > 0:
            CommandOptions.DBUS_HOST = value
        elif hasattr(args, l1l1l_opy_ (u"ࠪࡨࡧࡻࡳࡩࡱࡶࡸࠬࢼ")) and args.dbushost:
            CommandOptions.DBUS_HOST = args.dbushost
        value = os.environ.get(l1l1l_opy_ (u"ࠫࡒࡋࡓࡔࡃࡊࡉࡤࡈࡕࡔࡡࡖ࡙ࡇࡥࡐࡐࡔࡗࠫࢽ"))
        if value is not None and len(value) > 0:
            CommandOptions.DBUS_SUB_PORT = value
        elif hasattr(args, l1l1l_opy_ (u"ࠬࡹࡵࡣࡲࡲࡶࡹ࠭ࢾ")) and args.subport:
            CommandOptions.DBUS_SUB_PORT = args.subport
        value = os.environ.get(l1l1l_opy_ (u"࠭ࡍࡆࡕࡖࡅࡌࡋ࡟ࡃࡗࡖࡣࡕ࡛ࡂࡠࡒࡒࡖ࡙࠭ࢿ"))
        if value is not None and len(value) > 0:
            CommandOptions.DBUS_PUB_PORT = value
        elif hasattr(args, l1l1l_opy_ (u"ࠧࡱࡷࡥࡴࡴࡸࡴࠨࣀ")) and args.pubport:
            CommandOptions.DBUS_PUB_PORT = args.pubport
        value = os.environ.get(l1l1l_opy_ (u"ࠨࡋࡑࡊࡑ࡛ࡘࡠࡆࡅࡣࡍࡕࡓࡕࠩࣁ"))
        if value is not None and len(value) > 0:
            CommandOptions.DBASE_HOST = value
        elif hasattr(args, l1l1l_opy_ (u"ࠩࡧࡦࡦࡹࡥࡩࡱࡶࡸࠬࣂ")) and args.dbasehost:
            CommandOptions.DBASE_HOST = args.dbasehost
        value = os.environ.get(l1l1l_opy_ (u"ࠪࡍࡓࡌࡌࡖ࡚ࡢࡈࡇࡥࡁࡑࡋࡢࡔࡔࡘࡔࠨࣃ"))
        if value is not None and len(value) > 0:
            CommandOptions.DBASE_PORT = value
        elif hasattr(args, l1l1l_opy_ (u"ࠫࡩࡨࡡࡴࡧࡳࡳࡷࡺࠧࣄ")) and args.dbaseport:
            CommandOptions.DBASE_PORT = args.dbaseport
        value = os.environ.get(l1l1l_opy_ (u"ࠬࡇࡕࡕࡊࡢࡇࡑࡏࡅࡏࡖࡢࡍࡉ࠭ࣅ"))
        if value is not None and len(value) > 0:
            CommandOptions.AUTH_CLIENT_ID = value
        elif hasattr(args, l1l1l_opy_ (u"࠭ࡡࡶࡶ࡫ࡇࡱ࡯ࡥ࡯ࡶࡌࡨࠬࣆ")) and args.authClientId:
            CommandOptions.AUTH_CLIENT_ID = args.authClientId
        value = os.environ.get(l1l1l_opy_ (u"ࠧࡂࡗࡗࡌࡤࡉࡌࡊࡇࡑࡘࡤ࡙ࡅࡄࡔࡈࡘࠬࣇ"))
        if value is not None and len(value) > 0:
            CommandOptions.AUTH_CLIENT_SECRET = value
        elif hasattr(args, l1l1l_opy_ (u"ࠨࡣࡸࡸ࡭ࡉ࡬ࡪࡧࡱࡸࡘ࡫ࡣࡳࡧࡷࠫࣈ")) and args.authClientSecret:
            CommandOptions.AUTH_CLIENT_SECRET = args.authClientSecret
        value = os.environ.get(l1l1l_opy_ (u"ࠩࡄ࡙࡙ࡎ࡟ࡄࡎࡌࡉࡓ࡚࡟ࡂࡅࡆࡉࡘ࡙࡟ࡕࡑࡎࡉࡓ࠭ࣉ"))
        if value is not None and len(value) > 0:
            CommandOptions.AUTH_ACCESS_TOKEN = value
        elif hasattr(args, l1l1l_opy_ (u"ࠪࡥࡺࡺࡨࡂࡥࡦࡩࡸࡹࡔࡰ࡭ࡨࡲࠬ࣊")) and args.authAccessToken:
            CommandOptions.AUTH_ACCESS_TOKEN = args.authAccessToken
    def get_parse(self):
        return argparse.ArgumentParser()