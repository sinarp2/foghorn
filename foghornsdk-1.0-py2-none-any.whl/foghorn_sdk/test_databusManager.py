# test_databusManager.py
# The information in these files is the proprietary and confidential information of Foghorn Systems, Inc., ("Foghorn").
# Unless you have a valid license agreement with Foghorn, you may not access or use these files without the prior express written
# consent of Foghorn.
#
# Copyright (c) 2016 FogHorn Systems, Inc. All rights reserved
#

import zmq
from mock import MagicMock, Mock
from databus_manager import DatabusManager
from topic import Topic
from topic_type import TopicType
from unittest import TestCase


class TestDatabusManager(TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def set_up(self, mock_start=True, subscriber_none=False):
        mock_client = Mock()
        mock_log = Mock()
        mock_context = Mock()
        mock_socket_pub = Mock()
        if subscriber_none:
            mock_socket_sub = None
        else:
            mock_socket_sub = Mock()
        DatabusManager.create_context = MagicMock(return_value=mock_context)
        DatabusManager.create_publisher_socket = MagicMock(return_value=mock_socket_pub)
        DatabusManager.create_subscriber_socket = MagicMock(return_value=mock_socket_sub)
        if mock_start:
            DatabusManager.start = MagicMock(return_value=None)

        return DatabusManager(mock_log, mock_client)

    def test_initialize(self):
        mock_client = Mock()
        mock_log = Mock()

        databus = DatabusManager(mock_log, mock_client)
        assert databus._DatabusManager__logger == mock_log
        assert databus._DatabusManager__client == mock_client
        assert databus._DatabusManager__exit_flag == 0
        assert databus._DatabusManager__context is None
        assert databus._DatabusManager__publisher is None
        assert databus._DatabusManager__subscriber is None

    def test_initialize_2(self):

        databus = self.set_up()
        databus.initialize(hwm=1000)

        assert databus._DatabusManager__subscriber.connect.call_count == 1
        assert databus._DatabusManager__publisher.connect.call_count == 1

        databus._DatabusManager__subscriber.connect.assert_any_call(databus.get_sub_address())
        databus._DatabusManager__publisher.connect.assert_any_call(databus.get_pub_address())

        assert databus.start.call_count == 1
        assert databus.threadID == 1

    def test_add_subscriber(self):

        databus = self.set_up()
        databus.initialize(hwm=1000)

        topic = Topic("name1", {""}, TopicType.RAW, "id1")
        databus.add_subscriber(topic)

        assert databus._DatabusManager__subscriber.setsockopt.call_count == 2
        databus._DatabusManager__subscriber.setsockopt.assert_any_call(zmq.SUBSCRIBE, topic.get_name())

    def test_add_unsubscribe(self):

        databus = self.set_up()
        databus.initialize(hwm=1000)

        topic = Topic("name1", {""}, TopicType.RAW, "id1")
        databus.unsubscribe(topic)

        assert databus._DatabusManager__subscriber.setsockopt.call_count == 2
        databus._DatabusManager__subscriber.setsockopt.assert_any_call(zmq.UNSUBSCRIBE, topic.get_name())

    def test_publish_data(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)

        databus.publish_data('topic1', [1, 2, 3])
        databus._DatabusManager__publisher.send_multipart.assert_called_once_with(['topic1', [1, 2, 3]])

    def test_publish_data_2(self):
        databus = self.set_up()

        databus.publish_data('topic1', [1, 2, 3])

        assert databus._DatabusManager__publisher is None

    def test_publish_data_3(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)
        databus._DatabusManager__publisher.send_multipart = Mock(side_effect=Exception('boom'))

        self.assertRaises(Exception, databus.publish_data, 'topic1', [1, 2, 3])

    def test_publish_status(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)
        databus.publish_status([1, 2, 3])
        databus._DatabusManager__publisher.send_multipart.assert_called_once_with([databus._DatabusManager__STATUS_TOPIC, [1, 2, 3]])

    def test_create_publisher_exception(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)
        databus._DatabusManager__publisher.connect = Mock(side_effect=Exception('boom'))

        databus.create_publisher(hwm=1000)

        assert databus._DatabusManager__publisher is None

    def test_create_subscriber_exception(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)
        databus._DatabusManager__subscriber.connect = Mock(side_effect=Exception('boom'))

        databus.create_subscriber(hwm=1000)

        assert databus._DatabusManager__subscriber is None

    def test_create_subscriber_zero_hwm(self):
        databus = self.set_up()
        databus.initialize(hwm=0)
        databus.create_subscriber(hwm=0)

        databus._DatabusManager__subscriber.connect.call_count == 2

    def test_run_no_subscriber(self):
        databus = self.set_up(subscriber_none=True)
        databus.initialize(hwm=1000)
        databus.run()

    def test_run_empty_zmq_message(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)
        databus._DatabusManager__subscriber.recv_multipart = Mock(return_value=[])
        databus._DatabusManager__run_once = True
        databus.run()

        assert databus._DatabusManager__client.call_count == 0
        databus._DatabusManager__subscriber.recv_multipart.call_count == 1

    def test_run_status_message(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)
        databus._DatabusManager__subscriber.recv_multipart = Mock(return_value=[databus._DatabusManager__STATUS_TOPIC])
        databus._DatabusManager__run_once = True
        databus.run()

        assert databus._DatabusManager__client.call_count == 0
        databus._DatabusManager__subscriber.recv_multipart.call_count == 1

    def test_run_metrics_message(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)
        databus._DatabusManager__subscriber.recv_multipart = Mock(return_value=[databus._DatabusManager__METRICS_TOPIC])
        databus._DatabusManager__run_once = True
        databus.run()

        assert databus._DatabusManager__client.call_count == 0
        databus._DatabusManager__subscriber.recv_multipart.call_count == 1

    def test_run_control_message(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)
        databus._DatabusManager__subscriber.recv_multipart = Mock(return_value=[databus._DatabusManager__CONTROL_TOPIC, [1,2,3]])
        databus._DatabusManager__run_once = True
        databus.run()

        databus._DatabusManager__client.on_system_event.assert_called_once_with(databus._DatabusManager__CONTROL_TOPIC, [1,2,3])
        databus._DatabusManager__subscriber.recv_multipart.call_count == 1

    def test_run_data_message(self):
        databus = self.set_up()
        databus.initialize(hwm=1000)
        databus._DatabusManager__subscriber.recv_multipart = Mock(return_value=['/raw/mqtt/speed', [1,2,3]])
        databus._DatabusManager__run_once = True
        databus.run()

        databus._DatabusManager__client.on_system_event.assert_not_called()
        databus._DatabusManager__client.on_message.assert_called_once_with('/raw/mqtt/speed', [1,2,3])
        databus._DatabusManager__subscriber.recv_multipart.call_count == 1
