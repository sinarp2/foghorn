# test_TimeSeriesDatabase.py
# The information in these files is the proprietary and confidential information of Foghorn Systems, Inc., ("Foghorn").
 # Unless you have a valid license agreement with Foghorn, you may not access or use these files without the prior express written
 # consent of Foghorn.
 #
 # Copyright (c) 2016 FogHorn Systems, Inc. All rights reserved
#
import os
from unittest import TestCase

from mock import MagicMock, Mock

from configuration_manager_rest import ConfigurationManagerRest
from time_series_database import TimeSeriesDatabase


class TestTimeSeriesDatabase(TestCase):

    TESTDATA_FILENAME = os.path.join(os.path.dirname(__file__), 'test-edge-descriptor.json')
    TESTDATA2_FILENAME = os.path.join(os.path.dirname(__file__), 'test-edge-descriptor2.json')

    @classmethod
    def setUpClass(self):
        self.testdata = open(TestTimeSeriesDatabase.TESTDATA_FILENAME).read()
        self.testdata2 = open(TestTimeSeriesDatabase.TESTDATA2_FILENAME).read()

    @classmethod
    def tearDownClass(self):
        pass


    def test_create_database_with_rentention_policy(self):
        """
        Test the get_retention_period method when it is  defined in edge configuration.
        :param EdgeConnection:
        :return:
        """
        config_manager = ConfigurationManagerRest(Mock(), "app_id_1")
        config_manager.get_retention_period = MagicMock(return_value=None)
        database = TimeSeriesDatabase('user1', 'pswd1', Mock(), config_manager)
        database.query = MagicMock()
        database.create_database_with_rentention_policy("foo_db")
        self.assertTrue(database.query.call_count == 2)
