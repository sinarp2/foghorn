# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l11_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l1_opy_ = ord (ll_opy_ [-1])
    l1111_opy_ = ll_opy_ [:-1]
    l111_opy_ = l11l1_opy_ % len (l1111_opy_)
    l1lll_opy_ = l1111_opy_ [:l111_opy_] + l1111_opy_ [l111_opy_:]
    if l1_opy_:
        l11l_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    else:
        l11l_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    return eval (l11l_opy_)
import time
import os
import sys
from requests.exceptions import ConnectionError
def run_with_retry(l1lll111_opy_, l1llll1l_opy_):
	max_tries = int(os.environ.get(l1l1l_opy_ (u"ࠩࡵࡩࡹࡸࡹࡎࡣࡻࠫ࢟"), 5))
	l1lll1l1_opy_ = int(os.environ.get(l1l1l_opy_ (u"ࠪࡶࡪࡺࡲࡺ࡙ࡤ࡭ࡹࡓࡓࠨࢠ"), 20000))
	l1lll11l_opy_ = os.environ.get(l1l1l_opy_ (u"ࠫࡷ࡫ࡴࡳࡻࡈࡼ࡮ࡺࡏ࡯ࡇࡵࡶࡴࡸࠧࢡ"), False)
	l1lllll1_opy_ = 0
	l1lll1ll_opy_ = False
	logger = l1lll111_opy_
	while not l1lll1ll_opy_:
		l1lll1ll_opy_ = True
		try:
			result = l1llll1l_opy_.result()
			return result
		except ConnectionError as l1llll11_opy_:
			l1lllll1_opy_ += 1
			if l1lllll1_opy_ > max_tries:
				logger.log_error(l1l1l_opy_ (u"ࠧࡢ࡮ࡄࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤࡹࡵࠠࡆࡏࠣࡷࡹ࡯࡬࡭ࠢࡩࡥ࡮ࡲࡥࡥ࠮ࠣࡷࡹࡵࡰࠡࡴࡨࡸࡷࡿࡩ࡯ࡩ࠱ࡠࡳࠨࢢ"))
				if l1lll11l_opy_ in [l1l1l_opy_ (u"࠭ࡔࡳࡷࡨࠫࢣ"), l1l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬࢤ"), l1l1l_opy_ (u"ࠨࡖࡕ࡙ࡊ࠭ࢥ"), l1l1l_opy_ (u"ࠩ࠴ࠫࢦ")]:
					sys.exit(1)
				raise l1llll11_opy_
			logger.log_warning(l1l1l_opy_ (u"ࠥࡠࡳࡉ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠢࡷࡳࠥࡋࡍࠡࡨࡤ࡭ࡱ࡫ࡤ࠭ࠢࡵࡩࡹࡸࡹࡪࡰࡪ࠲࠳࠴࠮࠯ࠢࡾ࠴ࢂࠦ࡜࡯ࠤࢧ").format(l1lllll1_opy_))
			l1lll1ll_opy_ = False
			time.sleep(l1lll1l1_opy_/1000)
		except Exception as ex:
			logger.log_error(l1l1l_opy_ (u"ࠦࡡࡴࠠࡖࡰࡨࡼࡵ࡫ࡣࡵࡧࡧࠤࡪࡸࡲࡰࡴࠣࡩࡳࡩ࡯ࡶࡰࡷࡩࡷ࡫ࡤࠡࡹ࡫ࡩࡳࠦࡲࡶࡰࡢࡻ࡮ࡺࡨࡠࡴࡨࡸࡷࡿࠬࠡࡧࡻࠤ࠿ࠦ࡜࡯ࠤࢨ"), ex)
			print(l1l1l_opy_ (u"ࠧࡢ࡮ࠣࢩ"))
			raise ex