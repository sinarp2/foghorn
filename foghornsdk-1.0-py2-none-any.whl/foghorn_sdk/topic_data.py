# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l11_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l1_opy_ = ord (ll_opy_ [-1])
    l1111_opy_ = ll_opy_ [:-1]
    l111_opy_ = l11l1_opy_ % len (l1111_opy_)
    l1lll_opy_ = l1111_opy_ [:l111_opy_] + l1111_opy_ [l111_opy_:]
    if l1_opy_:
        l11l_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    else:
        l11l_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    return eval (l11l_opy_)
class TopicData(object):
    l11l11_opy_ = l1l1l_opy_ (u"ࠢࡕ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠥࡐ");
    l111ll_opy_ = l1l1l_opy_ (u"ࠣࡖࡵࡥࡨ࡫ࡉࡥࠤࡑ");
    def __init__(self, topic, raw_data, json_data):
        self.topic = topic
        self.raw_data = raw_data
        self.json_data = json_data
        self.l111l1_opy_ = {}
    def get_raw_data(self):
        return self.raw_data
    def get_data(self):
        return self.json_data
    def get_topic(self):
        return self.topic
    def get_metadata(self):
        return self.l111l1_opy_
    def get_timestamp(self):
        if TopicData.l11l11_opy_ in self.l111l1_opy_:
            return self.l111l1_opy_[TopicData.l11l11_opy_]
        else:
            return 0
    def get_traceid(self):
        if TopicData.l111ll_opy_ in self.l111l1_opy_:
            return self.l111l1_opy_[TopicData.l111ll_opy_]
        else:
            return l1l1l_opy_ (u"ࠤࠥࡒ")