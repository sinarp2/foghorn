# test_system_event.py
# The information in these files is the proprietary and confidential information of Foghorn Systems, Inc., ("Foghorn").
# Unless you have a valid license agreement with Foghorn, you may not access or use these files without the prior express written
# consent of Foghorn.
#
# Copyright (c) 2016 FogHorn Systems, Inc. All rights reserved
#
from unittest import TestCase

from mock import MagicMock, Mock

from system_event import SystemEvent


class TestSystemEvent(TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_parse_sensor_refresh(self):
        data = "{\"type\":\"sensor_refresh\", \"id\":\"xyz\",\"data\":{\"topics\":[\"abc  \",\"def\"]}}"
        system_event = SystemEvent.from_json(data)

        assert system_event.get_type() == SystemEvent.SENSOR_REFRESH
        assert system_event.get_id() == "xyz"
        assert system_event.get_data() == {'topics':['abc  ', 'def']}


    def test_parse_no_data(self):
        data = "{\"type\":\"sensor_refresh\", \"id\":\"xyz\"}"
        system_event = SystemEvent.from_json(data)

        assert system_event.get_type() == SystemEvent.SENSOR_REFRESH
        assert system_event.get_id() == "xyz"
        assert system_event.get_data() is None
