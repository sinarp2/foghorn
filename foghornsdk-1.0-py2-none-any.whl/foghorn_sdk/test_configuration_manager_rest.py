# test_configuration_manager_rest.py
# The information in these files is the proprietary and confidential information of Foghorn Systems, Inc., ("Foghorn").
# Unless you have a valid license agreement with Foghorn, you may not access or use these files without the prior express written
# consent of Foghorn.
#
# Copyright (c) 2016 FogHorn Systems, Inc. All rights reserved
#
from unittest import TestCase

from mock import MagicMock, Mock

from configuration_manager_rest import ConfigurationManagerRest
from schema_type import SchemaType
from topic import Topic
from topic_type import TopicType


class TestConfigurationManagerREST(TestCase):

    NEW_TOPIC_MESSAGE = '{"id":"7496dc01-9902-4efb-802b-2c543d1962c1","type":"new_topic"}'
    NEW_CONFIG_MESSAGE = '{"id":1, "type":"config"}'

    def setUp(self):
        self.mock_logger = Mock()
        self.mock_create_client = Mock()

    def tearDown(self):
        pass

    def test_init(self):
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)
        config = ConfigurationManagerRest(self.mock_logger, None)

        assert config.logger == self.mock_logger
        assert config.client is not None
        assert config._ConfigurationManagerRest__system_event_handler is None
        assert config.application_id is None

    def test_init_2(self):
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)
        config = ConfigurationManagerRest(self.mock_logger, "id_100")

        assert config.logger == self.mock_logger
        assert config.client is not None
        assert config._ConfigurationManagerRest__system_event_handler is None
        assert config.application_id == 'id_100'

    def test_close(self):
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)
        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        config.close()

    def test_get_topics_no_topic(self):
        topic = Mock()
        future = Mock()
        future.result = MagicMock(return_value=None) # return None topics
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topics = config.get_topics()

        assert topics is not None
        assert len(topics) == 0
        assert self.mock_create_client.Topic.getTopics.call_count == 1

    def test_get_topics_one_topic(self):
        topic = Mock()
        future = Mock()
        mock_topic = self.create_topics(1)
        future.result = MagicMock(return_value=mock_topic)
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topics = config.get_topics()

        assert topics is not None
        assert len(topics) == 1
        assert self.mock_create_client.Topic.getTopics.call_count == 1
        assert topics[0].get_name() == 'pressure'
        assert len(topics[0].get_tags()) == 2

    def test_get_topic_without_tag(self):
        topic = Mock()
        future = Mock()
        mock_topic = self.create_topics(3)
        future.result = MagicMock(return_value=mock_topic)
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topic = config.get_topic('wind')

        assert topic is not None
        assert topic.get_name() == 'wind'
        assert topic.get_topic_type() == TopicType.RAW

    def test_get_topic_with_decoded_tag(self):
        topic = Mock()
        future = Mock()
        mock_topic = self.create_topics(4)
        future.result = MagicMock(return_value=mock_topic)
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topic = config.get_topic('wind_decoded')

        assert topic is not None
        assert topic.get_name() == 'wind_decoded'
        assert topic.get_topic_type() == TopicType.DECODED

    def test_get_topic_system_topic(self):
        topic = Mock()
        future = Mock()
        mock_topic = self.create_topics(3)
        future.result = MagicMock(return_value=mock_topic)
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topic = config.get_topic('.control')

        assert topic is None

    def test_get_topics_one_system_topic(self):
        topic = Mock()
        future = Mock()
        mock_topic = self.create_topics(2)
        future.result = MagicMock(return_value=mock_topic)
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topics = config.get_topics()
        assert topics is not None
        assert len(topics) == 1
        assert self.mock_create_client.Topic.getTopics.call_count == 1
        assert topics[0].get_name() == 'pressure'
        assert len(topics[0].get_tags()) == 2

    def test_get_topics_rest_exception(self):
        topic = Mock()
        future = Mock()
        mock_result = Mock()
        mock_result.side_effect = Exception('Boom!')
        future.result = mock_result
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        try:
            topics = config.get_topics()
        except Exception as e:
            assert e.message == 'Boom!'
            assert self.mock_create_client.Topic.getTopics.call_count == 1
            return

        assert False

    def test_get_topic_does_not_exist(self):
        topic = Mock()
        future = Mock()
        mock_topic = self.create_topics(2)
        future.result = MagicMock(return_value=mock_topic)
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topics = config.get_topic("foo")
        assert topics is None
        assert self.mock_create_client.Topic.getTopics.call_count == 1

    def test_get_topic_does_exist(self):
        topic = Mock()
        future = Mock()
        mock_topic = self.create_topics(2)
        future.result = MagicMock(return_value=mock_topic)
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)
        ConfigurationManagerRest.get_topic_schema = MagicMock(return_value='{\'type\': \'number\'}')

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topic_ = config.get_topic("pressure")
        assert topic_ is not None
        assert self.mock_create_client.Topic.getTopics.call_count == 1
        assert topic_.get_name() == 'pressure'
        assert len(topic_.get_tags()) == 2
        assert topic_.get_id() == 'MyTestTopic'

    def test_system_topics(self):
        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")

        topic = Topic("name1", {""}, SchemaType.JSON, "101_id", [])
        assert config.is_system_topic(topic) == False

        topic = Topic("name1", {""}, SchemaType.JSON, "101_id", [TopicType.RAW])
        assert config.is_system_topic(topic) == False

        topic = Topic("name1", {""}, SchemaType.JSON, "101_id", [TopicType.ANALYTICS])
        assert config.is_system_topic(topic) == False

        topic = Topic("name1", {""}, SchemaType.JSON, "101_id", [TopicType.PROCESSED])
        assert config.is_system_topic(topic) == False

        topic = Topic("name1", {""}, SchemaType.JSON, "101_id", [TopicType.CONTROL])
        assert config.is_system_topic(topic)

        topic = Topic("name1", {""}, SchemaType.JSON, "101_id", [TopicType.SYSTEM])
        assert config.is_system_topic(topic)

        topic = Topic("name1", {""}, SchemaType.JSON, "101_id", [TopicType.STATUS])
        assert config.is_system_topic(topic)

        topic = Topic("name1", {""}, SchemaType.JSON, "101_id", [TopicType.METRICS])
        assert config.is_system_topic(topic)

    def test_create_topic(self):
        topic = Mock()
        future = Mock()
        future.result = MagicMock(return_value=None) # return None topics
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topic = config.create_topic("{\"type\":\"number\"}", SchemaType.JSON, "id_100", [])
        assert self.mock_create_client.get_model.call_count == 1
        assert self.mock_create_client.Topic.createTopic.call_count == 1
        assert topic is not None
        assert topic.get_id() == 'id_100'
        assert topic.get_tags()[0] == 'application'

    def test_create_topic_no_random_name(self):
        topic = Mock()
        future = Mock()
        future.result = MagicMock(return_value=None) # return None topics
        topic.getTopics = MagicMock(return_value=future)
        mock_client = Mock()
        mock_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=mock_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topic = config.create_topic("{\"type\":\"number\"}", SchemaType.JSON, "id_100", ['tag1', 'tag2'])
        assert mock_client.get_model.call_count == 1
        assert mock_client.Topic.createTopic.call_count == 1
        assert topic is not None
        assert topic.get_id() == 'id_100'
        assert topic.get_tags()[0] == 'application'
        assert topic.get_id() is topic.get_name()

    def test_create_topic_metadata_schema(self):
        topic = Mock()
        future = Mock()
        future.result = MagicMock(return_value=None) # return None topics
        topic.getTopics = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        topic = config.create_topic("key1:value1", SchemaType.METADATA, "id_100", [])

        assert self.mock_create_client.get_model.call_count == 1
        assert self.mock_create_client.Topic.createTopic.call_count == 1
        assert topic is not None
        assert topic.get_id() == 'id_100'
        assert topic.get_tags()[0] == 'application'

    def test_retention_period_zero_edge_descriptor(self):
        descriptor = Mock()
        future = Mock()
        future.result = MagicMock(return_value=[])
        descriptor.getDescriptors = MagicMock(return_value=future)
        self.mock_create_client.Descriptor = descriptor

        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)
        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        retention_period = config.get_retention_period()

        assert retention_period == 0

    def test_retention_period_one_edge_descriptor(self):
        descriptor = Mock()
        future = Mock()
        edge_descriptor = Mock()
        edge_descriptor.settings = Mock()
        edge_descriptor.settings.retentionPeriod = 1

        future.result = MagicMock(return_value=[edge_descriptor])
        descriptor.getDescriptors = MagicMock(return_value=future)
        self.mock_create_client.Descriptor = descriptor

        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)
        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        retention_period = config.get_retention_period()

        assert retention_period == 1

    def test_retention_period_exception(self):
        descriptor = Mock()
        future = Mock()
        future.result = MagicMock(return_value=[])
        mock = Mock()
        mock.side_effect = Exception('Boom!')
        descriptor.getDescriptors = mock
        self.mock_create_client.Descriptor = descriptor

        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)
        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        retention_period = config.get_retention_period()

        assert retention_period == 0

    def test_get_message_bus_high_water_mark(self):
        descriptor = Mock()
        future = Mock()
        edge_descriptor = Mock()
        edge_descriptor.settings = Mock()
        edge_descriptor.settings.mbusHighWaterMark = 987

        future.result = MagicMock(return_value=[edge_descriptor])
        descriptor.getDescriptors = MagicMock(return_value=future)
        self.mock_create_client.Descriptor = descriptor

        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)
        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        high_water_mark = config.get_message_bus_high_water_mark()

        assert high_water_mark == 987

    def test_system_event_new_topic_no_listerner(self):
        ConfigurationManagerRest.create_client = Mock()
        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        config.set_system_event_listener(None)
        config.on_system_event(TestConfigurationManagerREST.NEW_TOPIC_MESSAGE)

    def test_system_event_new_topic(self):

        topic = Mock()
        future = Mock()
        mock_topic = self.create_topics(1)
        future.result = MagicMock(return_value=mock_topic[0])
        topic.getTopic = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        mocker_listener = MagicMock()
        config.set_system_event_listener(mocker_listener)
        config.on_system_event(TestConfigurationManagerREST.NEW_TOPIC_MESSAGE)

        assert mocker_listener.on_system_event.call_count == 1

    def test_system_event_new_config(self):

        topic = Mock()
        future = Mock()
        mock_topic = self.create_topics(1)
        future.result = MagicMock(return_value=mock_topic[0])
        topic.getTopic = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        mocker_listener = MagicMock()
        config.set_system_event_listener(mocker_listener)
        config.on_system_event(TestConfigurationManagerREST.NEW_CONFIG_MESSAGE)

        assert mocker_listener.on_system_event.call_count == 1

    def test_system_event_exception(self):

        topic = Mock()
        future = Mock()
        mock_topic = Mock()
        future.result = MagicMock(return_value=mock_topic)
        topic.getTopic = MagicMock(return_value=future)
        self.mock_create_client.Topic = topic
        ConfigurationManagerRest.create_client = MagicMock(return_value=self.mock_create_client)

        config = ConfigurationManagerRest(self.mock_logger, "client_id_1")
        mocker_listener = MagicMock()
        config.set_system_event_listener(mocker_listener)
        config.on_system_event(TestConfigurationManagerREST.NEW_TOPIC_MESSAGE)

        assert mocker_listener.on_system_event.call_count == 0

    def create_topics(self, count):

        topic1 = None
        topic2 = None
        topic3 = None

        topic1 = Mock()
        topic1.description = ""
        topic1.format = None
        topic1.id = 'acbdb-djfkd-jdkfn-ksdjf9'
        topic1.jsonSchema = '{\'type\': \'number\'}'
        topic1.metadata = None
        topic1.parentId = None
        topic1.tags = ['sensorId:MyTestTopic', 'application']
        topic1.name = 'pressure'

        topic2 = Mock()
        topic2.description = ""
        topic2.format = None
        topic2.id = '100'
        topic2.jsonSchema = '{\'type\': \'number\'}'
        topic2.metadata = None
        topic2.parentId = None
        topic2.tags = ['control']
        topic2.name = '.control'

        topic3 = Mock()
        topic3.description = ""
        topic3.format = None
        topic3.id = 'acbdb-djfkd-jdkfn-ksdjf9'
        topic3.jsonSchema = '{\'type\': \'number\'}'
        topic3.metadata = None
        topic3.parentId = None
        topic3.tags = []
        topic3.name = 'wind'

        topic4 = Mock()
        topic4.description = ""
        topic4.format = None
        topic4.id = 'acbdb-djfkd-jdkfn-ksdjf9-decoded'
        topic4.jsonSchema = '{\'type\': \'number\'}'
        topic4.metadata = None
        topic4.parentId = None
        topic4.tags = ["raw","decoded"]
        topic4.name = 'wind_decoded'

        if count == 1:
            return [topic1]
        elif count == 2:
            return [topic1, topic2]
        elif count == 3:
            return [topic1, topic2, topic3]
        elif count == 4:
            return [topic1, topic2, topic3, topic4]

