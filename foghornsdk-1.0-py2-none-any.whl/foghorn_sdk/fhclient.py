# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l11_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l1_opy_ = ord (ll_opy_ [-1])
    l1111_opy_ = ll_opy_ [:-1]
    l111_opy_ = l11l1_opy_ % len (l1111_opy_)
    l1lll_opy_ = l1111_opy_ [:l111_opy_] + l1111_opy_ [l111_opy_:]
    if l1_opy_:
        l11l_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    else:
        l11l_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    return eval (l11l_opy_)
import json
import threading
from configuration_manager_rest import ConfigurationManagerRest
from databus_manager import DatabusManager
from foghorn_iam_client.auth_client import AuthClient
from cmd_option import CommandOptions
from health_reporter import HealthReporter
from topic_type import TopicType
from logger import Logger
from topic_data import TopicData
from topic_exception import TopicException
class FHClient():
    def __init__(self, application, report_health=False, message_bus_subscriber_high_water_mark=0, parse_command_option=True, client_id=None):
        if parse_command_option:
            self.create_command_option()
        self.__logger = self.create_logger()
        self.__logger.log_debug(l1l1l_opy_ (u"ࠣࡈࡋࡇࡱ࡯ࡥ࡯ࡶ࠱ࡣࡤ࡯࡮ࡪࡶࡢࡣࠧࠄ"))
        if not self.authenticate():
            raise Exception(l1l1l_opy_ (u"ࠤࡄࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡊࡦ࡯࡬ࡦࡦ࠱ࠦࠅ"))
        self.__1lll1_opy_ = threading.RLock()
        self.__1l1ll_opy_ = threading.RLock()
        self.__1ll1l_opy_ = None
        self.application_id = None
        if application is not None:
            if application.get_name() is None or len(str(application.get_name())) == 0:
                raise ValueError(l1l1l_opy_ (u"ࠥࡊࡍࡉ࡬ࡪࡧࡱࡸ࠳ࡥ࡟ࡪࡰ࡬ࡸࡤࡥࠠࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥࡴࡡ࡮ࡧࠣ࡭ࡸࠦ࡮ࡶ࡮࡯ࠤࡴࡸࠠࡦ࡯ࡳࡸࡾࠧࠢࠆ"))
            if application.get_version() is None or len(str(application.get_version())) == 0:
                raise ValueError(l1l1l_opy_ (u"ࠦࡋࡎࡃ࡭࡫ࡨࡲࡹ࠴࡟ࡠ࡫ࡱ࡭ࡹࡥ࡟ࠡࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳࠦࡶࡦࡴࡶ࡭ࡴࡴࠠࡪࡵࠣࡲࡺࡲ࡬ࠡࡱࡵࠤࡪࡳࡰࡵࡻࠤࠦࠇ"))
            if application.get_id() is None:
                raise ValueError(l1l1l_opy_ (u"ࠧࡌࡈࡄ࡮࡬ࡩࡳࡺ࠮ࡠࡡ࡬ࡲ࡮ࡺ࡟ࡠࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡪࡦࠣ࡭ࡸࠦ࡮ࡶ࡮࡯ࠥࠧࠈ"))
            else:
                self.application_id = str(application.get_id())
        else:
            self.application_id = client_id
        self.__topic_list = {}
        self.__configurationManager = self.create_config_mgr(self.application_id)
        self.__databusManager = self.create_databus(message_bus_subscriber_high_water_mark)
        if report_health:
            self.__1ll1l_opy_ = HealthReporter(self.__logger, application, self.__databusManager)
        self.__1l1l1_opy_ = None
        self.__topic_data_handler = None
    def close(self):
        l1l1l_opy_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࠠࠡࠢࠣࡇࡱࡵࡳࡦࠢࡷ࡬ࡪࠦࡣ࡭࡫ࡨࡲࡹࠦࡴࡰࠢࡵࡩࡱ࡫ࡡࡴࡧࠣ࡭ࡹࡹࠠࡳࡧࡶࡳࡺࡸࡣࡦࡵ࠱ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡀࡲࡦࡶࡸࡶࡳࡀࠠࡏࡱࡷ࡬࡮ࡴࡧࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧࠉ")
        self.__logger.log_debug(l1l1l_opy_ (u"ࠢࡇࡊࡆࡰ࡮࡫࡮ࡵ࠰ࡦࡰࡴࡹࡥࠣࠊ"))
        self.__exit_flag = 0
        self.__topic_list.clear();
        if self.__configurationManager is not None:
            self.__configurationManager.close()
        if self.__databusManager is not None:
            self.__databusManager.close()
        if self.__1ll1l_opy_ is not  None:
            self.__1ll1l_opy_.close()
    def get_topics(self):
        try:
            self.__logger.log_debug(l1l1l_opy_ (u"ࠣࡈࡋࡇࡱ࡯ࡥ࡯ࡶ࠱࡫ࡪࡺ࡟ࡵࡱࡳ࡭ࡨࡹࠢࠋ"))
            topics = self.__configurationManager.get_topics()
            return topics
        except Exception as e:
            self.__logger.log_error(l1l1l_opy_ (u"ࠤࡉࡌࡈࡲࡩࡦࡰࡷ࠲࡬࡫ࡴࡠࡶࡲࡴ࡮ࡩࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠯ࠢࡈࡶࡷࡵࡲ࠻ࠢࠥࠌ"), e)
            raise TopicException
    def get_topic(self, name):
        self.__logger.log_debug(l1l1l_opy_ (u"ࠥࡊࡍࡉ࡬ࡪࡧࡱࡸ࠳࡭ࡥࡵࡡࡷࡳࡵ࡯ࡣࠡࡰࡤࡱࡪࠦ࠽ࠡࠤࠍ") +str(name))
        if name is None or len(str(name)) == 0:
            raise ValueError(l1l1l_opy_ (u"ࠦࡋࡎࡃ࡭࡫ࡨࡲࡹ࠴ࡧࡦࡶࡢࡸࡴࡶࡩࡤࠢࡱࡥࡲ࡫ࠠࡪࡵࠣࡲࡺࡲ࡬ࠡࡱࡵࠤࡪࡳࡰࡵࡻࠤࠦࠎ"))
        try:
            topic = self.__configurationManager.get_topic(name)
            return topic
        except Exception as e:
            self.__logger.log_error(l1l1l_opy_ (u"ࠧࡌࡈࡄ࡮࡬ࡩࡳࡺ࠮ࡨࡧࡷࡣࡹࡵࡰࡪࡥࠣࡪࡦ࡯࡬ࡦࡦ࠱ࠤࡊࡸࡲࡰࡴ࠽ࠤࠧࠏ"), e)
            raise TopicException
    def add_topic_subscriber(self, topics, data_handler):
        if topics is None:
            self.__logger.log_error(l1l1l_opy_ (u"ࠨࡆࡉࡅ࡯࡭ࡪࡴࡴ࠯ࡣࡧࡨࡤࡺ࡯ࡱ࡫ࡦࡣࡸࡻࡢࡴࡥࡵ࡭ࡧ࡫ࡲࠡࡰࡸࡰࡱࠦࡴࡰࡲ࡬ࡧࡸࠧࠢࠐ"))
            raise ValueError(l1l1l_opy_ (u"ࠢࡇࡊࡆࡰ࡮࡫࡮ࡵ࠰ࡤࡨࡩࡥࡴࡰࡲ࡬ࡧࡤࡹࡵࡣࡵࡦࡶ࡮ࡨࡥࡳࠢࡷࡳࡵ࡯ࡣࠡ࡮࡬ࡷࡹࠦࡩࡴࠢࡱࡹࡱࡲࠢࠑ"))
        if data_handler is None:
            self.__logger.log_error(l1l1l_opy_ (u"ࠣࡈࡋࡇࡱ࡯ࡥ࡯ࡶ࠱ࡥࡩࡪ࡟ࡵࡱࡳ࡭ࡨࡥࡳࡶࡤࡶࡧࡷ࡯ࡢࡦࡴࠣࡲࡺࡲ࡬ࠡࡦࡤࡸࡦࡥࡨࡢࡰࡧࡰࡪࡸࠡࠣࠒ"))
            raise ValueError(l1l1l_opy_ (u"ࠤࡉࡌࡈࡲࡩࡦࡰࡷ࠲ࡦࡪࡤࡠࡶࡲࡴ࡮ࡩ࡟ࡴࡷࡥࡷࡨࡸࡩࡣࡧࡵࠤࡩࡧࡴࡢࡡ࡫ࡥࡳࡪ࡬ࡦࡴࠣ࡭ࡸࠦ࡮ࡶ࡮࡯ࠦࠓ"))
        if len(topics) == 0:
            self.__logger.log_warning(l1l1l_opy_ (u"ࠥࡊࡍࡉ࡬ࡪࡧࡱࡸ࠳ࡧࡤࡥࡡࡷࡳࡵ࡯ࡣࡠࡵࡸࡦࡸࡩࡲࡪࡤࡨࡶࠥࡺ࡯ࡱ࡫ࡦࡷࠥ࡫࡭ࡱࡶࡼࠥࠧࠔ"))
            return
        self.__1l1ll_opy_.acquire()
        for topic in topics:
            if topic.get_name() not in self.__topic_list:
                self.__databusManager.add_subscriber(topic)
                self.__topic_list[topic.get_name()] = topic
                self.__logger.log_debug(l1l1l_opy_ (u"ࠦࡋࡎࡃ࡭࡫ࡨࡲࡹ࠴ࡡࡥࡦࡢࡸࡴࡶࡩࡤࡡࡶࡹࡧࡹࡣࡳ࡫ࡥࡩࡷࠦࡴࡰࡲ࡬ࡧࠥࡃࠠࠣࠕ") + topic.get_name())
        self.__1l1ll_opy_.release()
        self.__topic_data_handler = data_handler
    def get_topic_data(self, topic, count):
        raise NotImplementedError
    def create_topic(self, schema, schema_type, topic_id, tags=[]):
        if schema is None or len(schema) == 0:
            raise ValueError(l1l1l_opy_ (u"ࠧࡌࡈࡄ࡮࡬ࡩࡳࡺ࠮ࡤࡴࡨࡥࡹ࡫࡟ࡵࡱࡳ࡭ࡨࠦࡳࡤࡪࡨࡱࡦࠦࡩࡴࠢࡱࡹࡱࡲࠠࡰࡴࠣࡩࡲࡶࡴࡺࠤࠖ"))
        if topic_id is None or len(topic_id) == 0:
            raise ValueError(l1l1l_opy_ (u"ࠨࡆࡉࡅ࡯࡭ࡪࡴࡴ࠯ࡥࡵࡩࡦࡺࡥࡠࡶࡲࡴ࡮ࡩࠠࡴࡥ࡫ࡩࡲࡧࠠࡪࡵࠣࡲࡺࡲ࡬ࠡࡱࡵࠤࡪࡳࡰࡵࡻࠥࠗ"))
        self.__logger.log_debug(l1l1l_opy_ (u"ࠢࡇࡊࡆࡰ࡮࡫࡮ࡵ࠰ࡦࡶࡪࡧࡴࡦࡡࡷࡳࡵ࡯ࡣ࠻ࠢࡖࡧ࡭࡫࡭ࡢࡖࡼࡴࡪࠦ࠽ࠡࠤ࠘") + schema_type + l1l1l_opy_ (u"ࠣࠢ࡬ࡨࠥࡃࠠࠣ࠙") + topic_id)
        return self.__configurationManager.create_topic(schema, schema_type, topic_id, tags)
    def publish_data(self, topic, data):
        if topic is None or len(str(topic.get_name())) == 0:
            raise ValueError(l1l1l_opy_ (u"ࠤࡉࡌࡈࡲࡩࡦࡰࡷ࠲ࡵࡻࡢ࡭࡫ࡶ࡬ࡤࡪࡡࡵࡣࠣࡸࡴࡶࡩࡤࠢ࡬ࡷࠥࡴࡵ࡭࡮ࠥࠚ"))
        if data is None:
            raise ValueError(l1l1l_opy_ (u"ࠥࡊࡍࡉ࡬ࡪࡧࡱࡸ࠳ࡶࡵࡣ࡮࡬ࡷ࡭ࡥࡤࡢࡶࡤࠤࡩࡧࡴࡢࠢ࡬ࡷࠥࡴࡵ࡭࡮ࠤࠦࠛ"))
        if topic.get_topic_type() != TopicType.APPLICATION:
            raise ValueError(l1l1l_opy_ (u"ࠦࡋࡎࡃ࡭࡫ࡨࡲࡹ࠴ࡰࡶࡤ࡯࡭ࡸ࡮࡟ࡥࡣࡷࡥࠥࡴ࡯ࡵࠢࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴࠠࡵࡱࡳ࡭ࡨࠧࠢࠜ"))
        id = self.get_application_id(topic)
        if id is None or id != self.application_id:
            raise RuntimeError(l1l1l_opy_ (u"ࠧࡌࡈࡄ࡮࡬ࡩࡳࡺ࠮ࡱࡷࡥࡰ࡮ࡹࡨࡠࡦࡤࡸࡦࠦࡰࡶࡤ࡯࡭ࡸ࡮ࠠࡵࡱࠣࡸࡴࡶࡩࡤࠢࡺ࡭ࡹ࡮ࠠࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠥ࡯ࡤࠡ࠿ࠣࠦࠝ") + id + l1l1l_opy_ (u"ࠨࠠ࡯ࡱࡷࠤࡦࡲ࡬ࡰࡹࡨࡨࠦࠨࠞ"))
        self.__databusManager.publish_data(topic.get_name(), data)
    def publish_string_topic_data(self, topic, data):
        if topic is None:
            raise ValueError(l1l1l_opy_ (u"ࠢࡇࡊࡆࡰ࡮࡫࡮ࡵ࠰ࡳࡹࡧࡲࡩࡴࡪࡢࡷࡹࡸࡩ࡯ࡩࡢࡸࡴࡶࡩࡤࡡࡧࡥࡹࡧࠠࡵࡱࡳ࡭ࡨࠦࡩࡴࠢࡱࡹࡱࡲࠢࠟ"))
        self.__databusManager.publish_data(topic, data)
    def subscribe_system_events(self, event_handler):
        if event_handler is None:
            raise ValueError(l1l1l_opy_ (u"ࠣࡈࡋࡇࡱ࡯ࡥ࡯ࡶ࠱ࡷࡺࡨࡳࡤࡴ࡬ࡦࡪࡥࡳࡺࡵࡷࡩࡲࡥࡥࡷࡧࡱࡸࡸࠦࡥࡷࡧࡱࡸࡤ࡮ࡡ࡯ࡦ࡯ࡩࡷࠦࡩࡴࠢࡱࡹࡱࡲࠢࠠ"))
        self.__configurationManager.set_system_event_listener(event_handler)
    def get_database(self, username, password):
        self.__logger.log_debug(l1l1l_opy_ (u"ࠤࡉࡌࡈࡲࡩࡦࡰࡷ࠲࡬࡫ࡴࡠࡦࡤࡸࡦࡨࡡࡴࡧࠥࠡ"))
        self.__1lll1_opy_.acquire()
        if self.__1l1l1_opy_ is None:
            from time_series_database import TimeSeriesDatabase
            self.__1l1l1_opy_ = TimeSeriesDatabase(username, password, self.__logger, self.__configurationManager)
        self.__1lll1_opy_.release()
        return self.__1l1l1_opy_
    def unsubscribe(self, topics):
        if topics is None:
            raise ValueError(l1l1l_opy_ (u"ࠥࡊࡍࡉ࡬ࡪࡧࡱࡸ࠳ࡻ࡮ࡴࡷࡥࡷࡨࡸࡩࡣࡧࠣࡸࡴࡶࡩࡤࡵࠣࡰ࡮ࡹࡴࠡ࡫ࡶࠤࡳࡵ࡮ࡦࠣࠥࠢ"))
        if len(topics) == 0:
            self.__logger.log_warning(l1l1l_opy_ (u"ࠦࡋࡎࡃ࡭࡫ࡨࡲࡹ࠴ࡵ࡯ࡵࡸࡦࡸࡩࡲࡪࡤࡨࠤࡹࡵࡰࡪࡥࡶࠤࡪࡳࡰࡵࡻࠤࠦࠣ"))
            return;
        success = True
        self.__logger.log_debug(l1l1l_opy_ (u"ࠧࡌࡈࡄ࡮࡬ࡩࡳࡺ࠮ࡶࡰࡶࡹࡧࡹࡣࡳ࡫ࡥࡩࠥࡩ࡯ࡶࡰࡷࠤࡂࠦࠢࠤ") + str(len(topics)))
        self.__1l1ll_opy_.acquire()
        for topic in topics:
            try:
                if topic.get_name() in self.__topic_list:
                    self.__databusManager.unsubscribe(topic)
                    del self.__topic_list[topic.get_name()]
                    self.__logger.log_debug(l1l1l_opy_ (u"ࠨࡆࡉࡅ࡯࡭ࡪࡴࡴ࠯ࡷࡱࡷࡺࡨࡳࡤࡴ࡬ࡦࡪࠦࡲࡦ࡯ࡲࡺࡪࡪ࠺ࠡࠤࠥ") + topic.get_name())
            except KeyError:
                success = False
                self.__logger.log_warning(l1l1l_opy_ (u"ࠢࡇࡊࡆࡰ࡮࡫࡮ࡵ࠰ࡸࡲࡸࡻࡢࡴࡥࡵ࡭ࡧ࡫ࠠࡧࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡶࡪࡳ࡯ࡷࡧ࠽ࠤࠧࠦ") + topic.get_name())
        self.__1l1ll_opy_.release()
        self.__logger.log_debug(l1l1l_opy_ (u"ࠣࡈࡋࡇࡱ࡯ࡥ࡯ࡶ࠱ࡹࡳࡹࡵࡣࡵࡦࡶ࡮ࡨࡥࠡࡦࡲࡲࡪࠦࡣࡰࡷࡱࡸࠥࡃࠠࠣࠧ") + str(len(self.__topic_list)))
        return success
    def get_logger(self):
        return self.__logger
    def on_message(self, topic, rawdata):
        l1ll11_opy_ = None
        l1l11l_opy_ = None
        self.__1l1ll_opy_.acquire()
        if topic in self.__topic_list:
            l1l11l_opy_ = self.__topic_list[topic]
        self.__1l1ll_opy_.release()
        if l1l11l_opy_ is not None:
            try:
                l1ll11_opy_ = json.loads(rawdata)
            except Exception as e:
                pass
            topicdata = TopicData(l1l11l_opy_, rawdata, l1ll11_opy_)
            try:
                if self.__topic_data_handler is not None:
                    self.__topic_data_handler.on_topic_data(topicdata)
                else:
                    self.__logger.log_error(l1l1l_opy_ (u"ࠤࡉࡌࡈࡲࡩࡦࡰࡷ࠲ࡴࡴ࡟࡮ࡧࡶࡷࡦ࡭ࡥࠡࡰࡲࠤࡹࡵࡰࡪࡥࡢࡨࡦࡺࡡࡠࡪࡤࡲࡩࡲࡥࡳࠤࠨ"))
            except Exception:
                pass
    def on_system_event(self, topic, data):
        self.__logger.log_debug(l1l1l_opy_ (u"ࠥࡊࡍࡉ࡬ࡪࡧࡱࡸ࠳ࡵ࡮ࡠࡵࡼࡷࡹ࡫࡭ࡠࡧࡹࡩࡳࡺࠠࡵࡱࡳ࡭ࡨࠦ࠽ࠡࠤࠩ") + str(topic))
        self.__configurationManager.on_system_event(data)
    def create_logger(self):
        return Logger.get_logger()
    def create_databus(self, hwm):
        databus = DatabusManager(self.__logger, self)
        databus.initialize(hwm)
        return databus
    def create_config_mgr(self, application_d):
        return ConfigurationManagerRest(self.__logger, application_d)
    def authenticate(self):
        if CommandOptions.AUTH_ACCESS_TOKEN is not None and len(str(CommandOptions.AUTH_ACCESS_TOKEN)) > 0:
            return True
        if CommandOptions.AUTH_CLIENT_ID is None or len(str(CommandOptions.AUTH_CLIENT_ID)) == 0 or CommandOptions.AUTH_CLIENT_SECRET is None or len(str(CommandOptions.AUTH_CLIENT_SECRET)) == 0:
            return True
        auth_client = self.get_auth_client()
        token = auth_client.get_app_token(CommandOptions.AUTH_CLIENT_ID, CommandOptions.AUTH_CLIENT_SECRET)
        return token is not None
    def create_command_option(self):
        co = CommandOptions()
        co.parse()
    def get_auth_client(self):
        return AuthClient(CommandOptions.EM_HOST, str(CommandOptions.EM_PORT))
    def get_application_id(self, topic):
        tags = topic.get_tags()
        if (tags is not None):
            for tag in tags:
                if tag.startswith(ConfigurationManagerRest.TAG_APP_ID):
                    return tag[len(ConfigurationManagerRest.TAG_APP_ID):]
        return None
    def get_descriptor(self):
        return self.__configurationManager.l1llll_opy_()