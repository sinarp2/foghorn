# test_logger.py
# The information in these files is the proprietary and confidential information of Foghorn Systems, Inc., ("Foghorn").
# Unless you have a valid license agreement with Foghorn, you may not access or use these files without the prior express written
# consent of Foghorn.
#
# Copyright (c) 2016 FogHorn Systems, Inc. All rights reserved
#
from unittest import TestCase

from mock import Mock, MagicMock

from logger import Logger


class TestLogger(TestCase):

    def setUp(self):
        self.mock_logger = MagicMock()
        Logger.create_logger = MagicMock(return_value=self.mock_logger)
        Logger.get_rotating_file_handler = Mock();
        self.logger = Logger()

    def tearDown(self):
        self.mock_logger = None
        self.logger

    def test_log_debug(self):
        self.logger.log_debug("foo")

        self.mock_logger.debug.assert_called_once_with("foo")
        assert Logger.create_logger.call_count == 1
        assert Logger.get_rotating_file_handler.call_count == 1

    def test_log_error(self):
        self.logger.log_error("foo")

        self.mock_logger.error.assert_called_once_with("foo")
        assert Logger.create_logger.call_count == 1
        assert Logger.get_rotating_file_handler.call_count == 1

    def test_log_error_with_exception(self):

        try:
            self.FOO
        except AttributeError as e:
            self.logger.log_error("foo", e)

        self.mock_logger.error.call_count == 1
        assert Logger.create_logger.call_count == 1
        assert Logger.get_rotating_file_handler.call_count == 1

    def test_log_warning(self):
        self.logger.log_warning("foo")

        self.mock_logger.warning.assert_called_once_with("foo")
        assert Logger.create_logger.call_count == 1
        assert Logger.get_rotating_file_handler.call_count == 1

    def test_log_info(self):
        self.logger.log_info("foo")

        self.mock_logger.info.assert_called_once_with("foo")
        assert Logger.create_logger.call_count == 1
        assert Logger.get_rotating_file_handler.call_count == 1
