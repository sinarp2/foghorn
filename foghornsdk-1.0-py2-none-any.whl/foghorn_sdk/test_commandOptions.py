import os
from unittest import TestCase

from mock import Mock, MagicMock

from cmd_option import CommandOptions


class TestCommandOptions(TestCase):

    def test_add_argument(self):
        mock_parser = Mock()
        CommandOptions.get_parse = MagicMock(return_value=mock_parser)
        options = CommandOptions()
        assert mock_parser.add_argument.call_count == 10

    def test_parse(self):
        mock_parser = Mock()
        mock_parser.parse_known_args = Mock(return_value=(Mock(), Mock()))
        CommandOptions.get_parse = MagicMock(return_value=mock_parser)
        options = CommandOptions()
        options.parse();
        assert mock_parser.parse_known_args.call_count == 1

    def test_parse_environments(self):
        mock_parser = Mock()
        mock_parser.parse_known_args = Mock(return_value=(Mock(), Mock()))
        CommandOptions.get_parse = MagicMock(return_value=mock_parser)

        os.environ['EDGE_MANAGER_HOST'] = '128.1.1.1'
        os.environ['EDGE_MANAGER_PORT'] = '666'
        os.environ['MESSAGE_BUS_HOST'] = '129.1.1.2'
        os.environ['MESSAGE_BUS_SUB_PORT'] = '667'
        os.environ['MESSAGE_BUS_PUB_PORT'] = '668'
        os.environ['INFLUX_DB_HOST'] = '130.1.1.3'
        os.environ['INFLUX_DB_API_PORT'] = '669'
        os.environ['AUTH_CLIENT_ID'] = 'ac_id'
        os.environ['AUTH_CLIENT_SECRET'] = 'ac_sec'
        os.environ['AUTH_CLIENT_ACCESS_TOKEN'] = 'ac_tocken'

        options = CommandOptions()
        options.parse();

        assert CommandOptions.EM_HOST == '128.1.1.1'
        assert CommandOptions.EM_PORT == '666'
        assert CommandOptions.DBUS_HOST == '129.1.1.2'
        assert CommandOptions.DBUS_SUB_PORT == '667'
        assert CommandOptions.DBUS_PUB_PORT == '668'
        assert CommandOptions.DBASE_HOST == '130.1.1.3'
        assert CommandOptions.DBASE_PORT == '669'
        assert CommandOptions.AUTH_CLIENT_ID == 'ac_id'
        assert CommandOptions.AUTH_CLIENT_SECRET == 'ac_sec'
        assert CommandOptions.AUTH_ACCESS_TOKEN == 'ac_tocken'

        assert mock_parser.parse_known_args.call_count == 1
