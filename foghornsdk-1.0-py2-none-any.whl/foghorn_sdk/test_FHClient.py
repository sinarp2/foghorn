# test_FHClient.py
# The information in these files is the proprietary and confidential information of Foghorn Systems, Inc., ("Foghorn").
# Unless you have a valid license agreement with Foghorn, you may not access or use these files without the prior express written
# consent of Foghorn.
#
# Copyright (c) 2016 FogHorn Systems, Inc. All rights reserved
#

import uuid
from unittest import TestCase

from mock import MagicMock, Mock

from configuration_manager_rest import ConfigurationManagerRest
from fhapplication import FHApplication
from health_status import HealthStatus
from system_event_handler import SystemEventHandler
from topic import Topic
from fhclient import FHClient
from schema_type import SchemaType
from topic_data_handler import TopicDataHandler
from topic_exception import TopicException
from topic_type import TopicType


class TestFHClient(TestCase):

    NEW_TOPIC_MESSAGE = '{"id":1,"topic":{"applicationData":{"appId":"22-100-26","appName":"MyApp","topicId":"Foo-Python-100"},"jsonSchema":{"type":"number"},"tags":["application"],"uri":"Foo-Python-100_8d2f98ab"},"type":"new_topic"}'

    NEW_CONFIG_MESSAGE = '{"id":1, "type":"config"}'

    @classmethod
    def setUp(cls):
        FHClient.create_logger = MagicMock()
        FHClient.create_command_option = MagicMock()

    def test_close(self):

        databus = MagicMock()
        config = MagicMock()

        FHClient.create_databus = MagicMock(return_value=databus)
        FHClient.create_config_mgr = MagicMock(return_value=config)

        fhclient = FHClient(self.create_app())

        fhclient.close()

        config.close.assert_called_once_with()
        databus.close.assert_called_once_with()
        assert FHClient.create_config_mgr.call_count == 1

    def test_get_topics(self):

        config = MagicMock()
        FHClient.create_config_mgr = MagicMock(return_value=config)

        topic1 = Topic("name1", {""}, SchemaType.JSON, "101_id")
        topic2 = Topic("name2", {""}, SchemaType.JSON, "102_id")

        config.get_topics = MagicMock(return_value=[topic1, topic2])
        fhclient = FHClient(self.create_app())
        topics = fhclient.get_topics()

        config.get_topics.assert_called_once_with()
        assert topics is not None
        assert len(topics) == 2
        assert topics[0].get_name() == "name1"
        assert topics[0].get_id() == "101_id"
        assert topics[1].get_name() == "name2"
        assert topics[1].get_id() == "102_id"

    def test_get_topics_1(self):

        config = MagicMock()
        FHClient.create_config_mgr = MagicMock(return_value=config)

        mock = Mock()
        mock.side_effect = Exception('Boom!')
        config.get_topics = mock

        fhclient = FHClient(self.create_app())

        success = False
        try:
            topics = fhclient.get_topics()
        except TopicException:
            success = True

        assert success

    def test_get_topic(self):

        config = MagicMock()
        FHClient.create_config_mgr = MagicMock(return_value=config)

        topic1 = Topic("name1", {""}, SchemaType.JSON, "101_id")
        topic2 = Topic("name2", {""}, SchemaType.JSON, "102_id")

        config.get_topics = MagicMock(return_value=[topic1, topic2])
        config.get_topic = MagicMock(return_value=topic1)

        fhclient = FHClient(self.create_app())
        topic = fhclient.get_topic("name1")

        config.get_topic.assert_called_once_with("name1")
        assert topic is not None
        assert topic.get_name() is "name1"
        assert topic.get_id() is "101_id"
        assert FHClient.create_config_mgr.call_count == 1

    def test_get_topic2(self):

        config = MagicMock()
        FHClient.create_config_mgr = MagicMock(return_value=config)

        mock = Mock()
        mock.side_effect = Exception('Boom!')
        config.get_topic = mock

        fhclient = FHClient(self.create_app())

        success = False
        try:
            topic = fhclient.get_topic("sensor1")
        except TopicException:
            success = True

        assert success
        assert FHClient.create_config_mgr.call_count == 1

    def test_add_topic_subscriber(self):

        config = MagicMock()
        databus = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=config)
        FHClient.create_databus = MagicMock(return_value= databus)

        topic1 = Topic("name1", {""}, SchemaType.JSON, "101_id")
        topic2 = Topic("name2", {""}, SchemaType.JSON, "102_id")
        config.get_topics = MagicMock(return_value=[topic1, topic2])

        app = self.create_app()
        listeners = self.create_listeners()
        fhclient = FHClient(app)
        topics = fhclient.get_topics()
        fhclient.add_topic_subscriber(topics, listeners)
        assert databus.add_subscriber.call_count == 2
        assert fhclient._FHClient__topic_data_handler is not None
        assert fhclient._FHClient__topic_data_handler == listeners
        assert len(fhclient._FHClient__topic_list) == 2

    def test_add_topic_subscriber_duplicate(self):
        # test that same topic can't be added twice
        config = MagicMock()
        databus = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=config)
        FHClient.create_databus = MagicMock(return_value= databus)

        topic1 = Topic("name1", {""}, SchemaType.JSON, "101_id")
        topic2 = Topic("name2", {""}, SchemaType.JSON, "102_id")

        app = self.create_app()
        listeners = self.create_listeners()
        fhclient = FHClient(app)

        fhclient.add_topic_subscriber([topic1, topic2], listeners)
        fhclient.add_topic_subscriber([topic2, topic1], listeners)

        assert databus.add_subscriber.call_count == 2
        assert fhclient._FHClient__topic_data_handler is not None
        assert fhclient._FHClient__topic_data_handler == listeners
        assert len(fhclient._FHClient__topic_list) == 2

    def test_publish_data(self):

        config = MagicMock()
        app = self.create_app();
        topic = Topic("name1", {""}, TopicType.APPLICATION, "id1", {ConfigurationManagerRest.TAG_APP_ID+str(app.get_id())})
        config.create_topic = MagicMock(return_value = topic)
        FHClient.create_config_mgr = MagicMock(return_value=config)
        databus = Mock()
        FHClient.create_databus = MagicMock(return_value=databus)

        FHClient.start = MagicMock(return_value=None)
        fhclient = FHClient(app)
        data = [1,2,3]
        fhclient.publish_data(topic, data)

        assert fhclient._FHClient__databusManager.publish_data.call_count == 1
        fhclient._FHClient__databusManager.publish_data.assert_called_once_with(topic.get_name(), data)

    def test_publish_data_1(self):
        # test publish_data when topic is none and ValueError is raised by sdk
        FHClient.create_config_mgr, FHClient.create_databus = self.create_mock_config_and_databus()

        FHClient.start = MagicMock(return_value=None)
        fhclient = FHClient(self.create_app())

        self.assertRaises(ValueError, fhclient.publish_data, None, [1, 2, 3])

    def test_publish_data_2(self):
        # test publish_data when data is none and ValueError is raised by sdk
        FHClient.create_config_mgr, FHClient.create_databus = self.create_mock_config_and_databus()

        fhclient = FHClient(self.create_app())
        topic = fhclient.create_topic({""}, SchemaType.JSON, "101_id")

        self.assertRaises(ValueError, fhclient.publish_data, topic, None)

    def test_publish_data_3(self):
        # test publish_data when topic type is not application and ValueError is raised by sdk

        config = MagicMock()
        topic = Topic("name1", {""}, TopicType.RAW, "id1")
        config.create_topic = MagicMock(return_value = topic)
        FHClient.create_config_mgr = MagicMock(return_value=config)
        databus = Mock()
        FHClient.create_databus = MagicMock(return_value=databus)

        fhclient = FHClient(self.create_app())
        topic = fhclient.create_topic({""}, SchemaType.JSON, "101_id")

        self.assertRaises(ValueError, fhclient.publish_data, topic, [1,2,3])

    def test_publish_data_4(self):
        # test when topic application id does not match client id.
        config = MagicMock()
        topic = Topic("name1", {""}, TopicType.APPLICATION, "id1", {ConfigurationManagerRest.TAG_APP_ID+"client_id_1"})
        config.create_topic = MagicMock(return_value = topic)
        FHClient.create_config_mgr = MagicMock(return_value=config)
        databus = Mock()
        FHClient.create_databus = MagicMock(return_value=databus)

        FHClient.start = MagicMock(return_value=None)
        fhclient = FHClient(self.create_app())

        self.assertRaises(RuntimeError, fhclient.publish_data, topic, [1,2,3])

    def test_get_database(self):
        FHClient.create_config_mgr = MagicMock()
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock()
        fhclient = FHClient(self.create_app())
        tsdb = fhclient.get_database('user1', 'pswd2')
        assert tsdb is not None

    def test_unsubscribe(self):

        config = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=config)
        databus = Mock()
        FHClient.create_databus = MagicMock(return_value=databus)

        topic1 = Topic("name1", {""}, SchemaType.JSON, "101_id")
        topic2 = Topic("name2", {""}, SchemaType.JSON, "102_id")

        config.get_topics = MagicMock(return_value=[topic1, topic2])

        FHClient.start = MagicMock(return_value=None)
        fhclient = FHClient(self.create_app())
        topics = fhclient.get_topics()
        fhclient.add_topic_subscriber(topics, self.create_listeners())

        assert topics is not None
        assert len(topics) == 2

        fhclient.unsubscribe(topics)
        topics = fhclient.get_topics()

        assert fhclient._FHClient__topic_list is not None
        assert len(fhclient._FHClient__topic_list) == 0
        assert databus.unsubscribe.call_count == 2
        assert len(databus.unsubscribe.mock_calls) == 2
        topic_arg = databus.unsubscribe.mock_calls[0][1][0]
        assert topic_arg.get_name() == "name1"
        assert topic_arg.get_id() == "101_id"
        topic_arg = databus.unsubscribe.mock_calls[1][1][0]
        assert topic_arg.get_name() == "name2"
        assert topic_arg.get_id() == "102_id"

    def test_unsubscribe_topic_not_present(self):

        config = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=config)
        databus = Mock()
        FHClient.create_databus = MagicMock(return_value=databus)

        topic1 = Topic("name1", {""}, SchemaType.JSON, "101_id")
        topic2 = Topic("name2", {""}, SchemaType.JSON, "102_id")

        FHClient.start = MagicMock(return_value=None)
        fhclient = FHClient(self.create_app())

        fhclient.add_topic_subscriber([topic1, topic2], self.create_listeners())

        fhclient.unsubscribe([topic1])
        fhclient.unsubscribe([topic1])

        assert fhclient._FHClient__topic_list is not None
        assert len(fhclient._FHClient__topic_list) == 1

    def test_on_message(self):
        # test on_message when topic is not in topic list.

        config = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=config)
        databus = Mock()
        FHClient.create_databus = MagicMock(return_value=databus)

        fhclient = FHClient(self.create_app())

        fhclient.on_message("topic1", [1,2,3])

        assert fhclient._FHClient__topic_data_handler is None

    def test_on_message_1(self):
        # test on_message when topic is not in topic list.

        config = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=config)
        databus = Mock()
        FHClient.create_databus = MagicMock(return_value=databus)

        listeners = self.create_listeners()
        fhclient = FHClient(self.create_app())
        topic1, topic2 = self.create_topics()
        topics = [topic1, topic2]
        fhclient.add_topic_subscriber(topics, listeners)

        fhclient.on_message("name1", [1,2,3])

        assert listeners.on_topic_data_called
        assert listeners.data is not None
        assert len(listeners.data.get_raw_data()) == 3
        assert listeners.data.get_topic().get_name() == "name1"

    def test_on_message_2(self):
        # application on_topic_data throw exception
        FHClient.create_config_mgr = MagicMock()
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock()

        listeners = self.create_listeners()
        listeners.on_topic_data_throw = True
        fhclient = FHClient(self.create_app())
        topic1, topic2 = self.create_topics()
        fhclient.add_topic_subscriber([topic1, topic2], listeners)
        fhclient.on_message("name1", [1,2,3])
        assert listeners.on_topic_data_called is False

    def test_on_system_event(self):
        # test system event when event can't be de-serialized
        mockConfigManager = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=mockConfigManager)
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock()
        fhclient = FHClient(self.create_app())
        listeners = self.create_listeners()
        fhclient.subscribe_system_events(listeners)
        fhclient.on_system_event(Mock(), "foo_event")
        assert mockConfigManager.is_application_topic.call_count == 0
        assert mockConfigManager.on_system_event.call_count == 1
        assert len(mockConfigManager.on_system_event.call_args_list) == 1

    def test_on_system_event_2(self):
        # test system event when event is not the right type.
        mockConfigManager = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=mockConfigManager)
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock()
        fhclient = FHClient(self.create_app())
        fhclient.on_system_event(Mock(), "{\"type\":\"number\"}")
        assert mockConfigManager.is_application_topic.call_count == 0

    def test_on_system_event_3(self):
        # test system event when event is not the expected format.
        mockConfigManager = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=mockConfigManager)
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock()
        fhclient = FHClient(self.create_app())
        fhclient.on_system_event(Mock(), "{\"typez\":\"number\"}")
        assert mockConfigManager.is_application_topic.call_count == 0

    def test_on_system_event_4(self):
        # test system event for a valid new topic message.
        mockConfigManager = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=mockConfigManager)
        mockConfigManager.is_application_topic = MagicMock(return_value=False)
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock()
        fhclient = FHClient(self.create_app())
        fhclient.subscribe_system_events(self.create_listeners())
        fhclient.on_system_event(Mock(), TestFHClient.NEW_TOPIC_MESSAGE)
        assert mockConfigManager.on_system_event.call_count == 1

    def test_on_system_event_5(self):
        # test system event for a valid new topic message, but it a self application created topic
        mockConfigManager = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=mockConfigManager)
        mockConfigManager.is_application_topic = MagicMock(return_value=True)
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock()
        fhclient = FHClient(self.create_app())
        fhclient.on_system_event(Mock(), TestFHClient.NEW_TOPIC_MESSAGE)
        assert mockConfigManager.on_system_event.call_count == 1

    def test_on_system_event_6(self):
        # test system event for a valid config message.
        mockConfigManager = Mock()
        FHClient.create_config_mgr = MagicMock(return_value=mockConfigManager)
        mockConfigManager.is_application_topic = MagicMock(return_value=True)
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock()
        fhclient = FHClient(self.create_app())
        fhclient.subscribe_system_events(self.create_listeners())
        fhclient.on_system_event(Mock(), TestFHClient.NEW_CONFIG_MESSAGE)
        assert mockConfigManager.on_system_event.call_count == 1
    def test_add_get_topic_2(self):
        self.assertRaises(ValueError, self.create_fhclient().get_topic, None)

    def test_add_topic_subscriber_2(self):
        self.assertRaises(ValueError, self.create_fhclient().add_topic_subscriber, None, None)

    def test_add_topic_subscriber(self):
        mock = MagicMock()
        FHClient.create_config_mgr = MagicMock()
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock(return_value =mock)
        FHClient.create_command_option = MagicMock()

        topic1 = Topic("name1", {""}, SchemaType.JSON, "101_id")
        topic2 = Topic("name2", {""}, SchemaType.JSON, "102_id")
        topics = [topic1, topic2]

        fhclient = FHClient(Mock(), False)
        fhclient.add_topic_subscriber(topics, Mock())
        assert mock.add_subscriber.call_count == 2
        assert len(fhclient._FHClient__topic_list) == 2

    def test_get_topic_data(self):
        self.assertRaises(NotImplementedError, self.create_fhclient().get_topic_data, None, None)

    def test_create_topic(self):
        self.assertRaises(ValueError, self.create_fhclient().create_topic, None, None, None)

    def test_create_topic2(self):
        self.assertRaises(ValueError, self.create_fhclient().create_topic, "schema", None, None)

    def test_unsubscribe_2(self):
        self.assertRaises(ValueError, self.create_fhclient().unsubscribe, None,)

    def test_get_logger(self):
        mock = MagicMock()
        FHClient.create_config_mgr = MagicMock()
        FHClient.create_logger = MagicMock(return_value =mock)
        FHClient.create_databus = MagicMock()
        fhclient = FHClient(Mock(), False)
        assert fhclient.get_logger() == mock

    """
    def test_authenticate_Fail(self):
        FHClient.create_command_option = Mock()
        FHClient.create_logger = Mock()
        FHClient.authenticate = MagicMock(return_value=False)
        self.assertRaises(Exception, FHClient.__init__, Mock, False)
    """

    def create_fhclient(self):
        FHClient.create_config_mgr = MagicMock()
        FHClient.create_logger = MagicMock()
        FHClient.create_databus = MagicMock()
        FHClient.create_command_option = MagicMock()
        fhclient = FHClient(Mock(), False)
        return fhclient

    def create_listeners(self):
        return Listeners()

    def create_topics(self):
        topic1 = Topic("name1", {""}, SchemaType.JSON, "101_id")
        topic2 = Topic("name2", {""}, SchemaType.JSON, "102_id")
        return topic1, topic2

    def create_mock_log(self):
        mockLog = MagicMock()
        return mockLog

    def create_mock_config_and_databus(self):
        config = Mock()
        databus = Mock()
        return config, databus

    def create_app(self):
        app = FHApplication("myname", "id1", "v1", "foghorn")
        app.get_name = MagicMock(return_value="foo")
        app.get_version = MagicMock(return_value="1.0")
        app.get_health_data = MagicMock(return_value=HealthStatus.running)
        id_ = uuid.uuid4()
        app.get_id = MagicMock(return_value=id_)
        app.on_topic_data = MagicMock()
        app.shutdown = MagicMock()
        return app


class Listeners(TopicDataHandler, SystemEventHandler):

    def __init__(self):
        self.on_system_event_called = False
        self.on_topic_data_called = False
        self.data = None
        self.event = None
        self.on_topic_data_throw = False
        self.on_system_event_throw = False

    def on_system_event(self, event):
        if self.on_system_event_throw:
            raise Exception
        self.on_system_event_called = True
        self.event = event

    def on_topic_data(self, data):
        if self.on_topic_data_throw:
            raise Exception
        self.on_topic_data_called = True
        self.data = data
