# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l11_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l1_opy_ = ord (ll_opy_ [-1])
    l1111_opy_ = ll_opy_ [:-1]
    l111_opy_ = l11l1_opy_ % len (l1111_opy_)
    l1lll_opy_ = l1111_opy_ [:l111_opy_] + l1111_opy_ [l111_opy_:]
    if l1_opy_:
        l11l_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    else:
        l11l_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    return eval (l11l_opy_)
import os
import json
import uuid
from bravado.client import SwaggerClient
from bravado.swagger_model import load_file
from foghorn_sdk.retry_loop import run_with_retry
from cmd_option import CommandOptions
from new_configuration_event import NewConfigurationEvent
from new_topic_event import NewTopicEvent
from schema_type import SchemaType
from topic import Topic
from topic_type import TopicType
from system_event import SystemEvent
class ConfigurationManagerRest(object):
    l111ll1_opy_ = l1l1l_opy_ (u"ࠤࡶࡩࡳࡹ࡯ࡳࡋࡧ࠾ࠧࢃ")
    TAG_APP_ID = l1l1l_opy_ (u"ࠥࡥࡵࡶࡉࡥ࠼ࠥࢄ")
    def __init__(self, logger, application_id):
        self.logger = logger
        self.application_id = application_id
        self.client = self.create_client()
        self.__system_event_handler = None
        self.request_options = {l1l1l_opy_ (u"ࠫࡨࡵ࡮࡯ࡧࡦࡸࡤࡺࡩ࡮ࡧࡲࡹࡹ࠭ࢅ"): 5}
        self.logger.log_debug(l1l1l_opy_ (u"ࠧࡉ࡯࡯ࡨ࡬࡫ࡺࡸࡡࡵ࡫ࡲࡲࡒࡧ࡮ࡢࡩࡨࡶࡗ࡫ࡳࡵ࠰ࡢࡣ࡮ࡴࡩࡵࡡࡢࠦࢆ"))
    def close(self):
        self.logger.log_debug(l1l1l_opy_ (u"ࠨࡃࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡓࡡ࡯ࡣࡪࡩࡷࡘࡥࡴࡶ࠱ࡧࡱࡵࡳࡦࠤࢇ"))
    def get_topics(self):
        self.logger.log_debug(l1l1l_opy_ (u"ࠢࡄࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࡍࡢࡰࡤ࡫ࡪࡸ࠮ࡨࡧࡷࡣࡹࡵࡰࡪࡥࡶࠦ࢈"))
        topics = self.l111l1l_opy_()
        l11l111_opy_ = []
        if topics is None or len(topics) == 0:
            self.logger.log_debug(l1l1l_opy_ (u"ࠣࡅࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡣࡱࡥ࡬࡫ࡲࡓࡧࡶࡸ࠳࡭ࡥࡵࡡࡷࡳࡵ࡯ࡣࡴࠢࡷࡳࡵ࡯ࡣࠡࡥࡲࡹࡳࡺࠠ࠾ࠢ࠳ࠦࢉ"))
            return l11l111_opy_
        self.logger.log_debug(l1l1l_opy_ (u"ࠤࡆࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࡏࡤࡲࡦ࡭ࡥࡳࡔࡨࡷࡹ࠴ࡧࡦࡶࡢࡸࡴࡶࡩࡤࡵࠣࡸࡴࡶࡩࡤࠢࡦࡳࡺࡴࡴࠡ࠿ࠣࠦࢊ") + str(len(topics)))
        for topic in topics:
            if self.is_system_topic(topic):
                continue
            schema = self.get_topic_schema(topic)
            l1l11l_opy_ = Topic(topic.name, schema, self.get_topic_type(topic), self.l1l11ll_opy_(topic), topic.tags)
            l11l111_opy_.append(l1l11l_opy_)
        return l11l111_opy_
    def get_topic(self, name):
        self.logger.log_debug(l1l1l_opy_ (u"ࠥࡇࡴࡴࡦࡪࡩࡸࡶࡦࡺࡩࡰࡰࡐࡥࡳࡧࡧࡦࡴࡕࡩࡸࡺ࠮ࡨࡧࡷࡣࡹࡵࡰࡪࡥࠣࡲࡦࡳࡥࠡ࠿ࠣࠦࢋ") + str(name))
        l1l11l_opy_ = None
        topic = self.l1l1111_opy_(name)
        if topic is None:
            self.logger.log_warning(l1l1l_opy_ (u"ࠦࡈࡵ࡮ࡧ࡫ࡪࡹࡷࡧࡴࡪࡱࡱࡑࡦࡴࡡࡨࡧࡵࡖࡪࡹࡴ࠯ࡩࡨࡸࡤࡺ࡯ࡱ࡫ࡦࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪࠠ࡯ࡣࡰࡩࠥࡃࠠࠣࢌ") + str(name))
            return l1l11l_opy_
        if self.is_system_topic(topic):
            return None
        schema = self.get_topic_schema(topic)
        l1l11l_opy_ = Topic(topic.name, schema, self.get_topic_type(topic), self.l1l11ll_opy_(topic), topic.tags)
        return l1l11l_opy_
    def create_topic(self, schema, schema_type, topic_id, tags):
        l1l11l1_opy_ = topic_id
        l111lll_opy_ = self.client.get_model(l1l1l_opy_ (u"࡚ࠬ࡯ࡱ࡫ࡦࡒࡪࡽࠧࢍ"))
        l11l11l_opy_ = l111lll_opy_(
            name=l1l11l1_opy_,
            description=None,
            format=None,
            tags=tags)
        l11lll1_opy_ = None
        if schema_type == SchemaType.JSON:
            l11lll1_opy_ = json.loads(schema)
            l11l11l_opy_.jsonSchema = l11lll1_opy_
        elif schema_type == SchemaType.METADATA:
            l11l11l_opy_.metadata = schema
        l11l11l_opy_.tags = [TopicType.APPLICATION, ConfigurationManagerRest.l111ll1_opy_ + topic_id]
        if self.application_id is not None:
            l11l11l_opy_.tags.append(ConfigurationManagerRest.TAG_APP_ID + str(self.application_id))
        self.logger.log_debug(l1l1l_opy_ (u"ࠨࡃࡰࡰࡩ࡭࡬ࡻࡲࡢࡶ࡬ࡳࡳࡓࡡ࡯ࡣࡪࡩࡷ࠴ࡣࡳࡧࡤࡸࡪࡥࡴࡰࡲ࡬ࡧࠥ࡯ࡤࠡ࠿ࠣࠦࢎ") + topic_id + l1l1l_opy_ (u"ࠢࠡࡗࡵ࡭ࠥࡃࠠࠣ࢏") + l1l11l1_opy_);
        run_with_retry(self.logger, self.client.Topic.createTopic(topic=l11l11l_opy_))
        l1l11l_opy_ = Topic(l1l11l1_opy_, schema, TopicType.APPLICATION, topic_id, l11l11l_opy_.tags);
        return l1l11l_opy_;
    def l111l1l_opy_(self):
        return run_with_retry(self.logger, self.client.Topic.getTopics(_request_options=self.request_options))
    def l1l1111_opy_(self, name):
        topics = self.l111l1l_opy_()
        if topics is None or len(topics) == 0:
            return None
        for index in range(len(topics)):
            topic = topics[index]
            if topic.name == name:
                return topic
        return None
    def l11llll_opy_(self, id):
        return run_with_retry(self.logger, self.client.Topic.getTopic(topicId=id, _request_options=self.request_options))
    def l1llll_opy_(self):
        try:
            l1l1l1l_opy_ = run_with_retry(self.logger, self.client.Descriptor.getDescriptors(_request_options=self.request_options))
            if len(l1l1l1l_opy_) > 0:
                return l1l1l1l_opy_[0]
            else:
                return None
        except Exception as ex:
            return None
    def get_retention_period(self):
        edge_descriptor = self.l1llll_opy_()
        if edge_descriptor is not None and edge_descriptor.settings is not None:
            return edge_descriptor.settings.retentionPeriod
        else:
            return 0
    def get_message_bus_high_water_mark(self):
        edge_descriptor = self.l1llll_opy_()
        if edge_descriptor is not None and edge_descriptor.settings is not None:
            return edge_descriptor.settings.mbusHighWaterMark
        else:
            return 0
    def create_client(self):
        l1l1l_opy_ (u"ࠨࠩࠪࠎࠥࠦࠠࠡࠢࠣࠤ࡛ࠥࡳࡪࡰࡪࠤࡹ࡮ࡥࠡࡵࡺࡥ࡬࡭ࡥࡳࠢࡩ࡭ࡱ࡫ࠠࡤࡴࡨࡥࡹ࡫ࡳࠡࡣࡱࡨࠥࡸࡥࡵࡷࡵࡲࡸࠦࡡࠡࡕࡺࡥ࡬࡭ࡥࡳࡅ࡯࡭ࡪࡴࡴࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠽ࡶࡪࡺࡵࡳࡰ࠽ࠤࡦࠦࡓࡸࡣࡪ࡫ࡪࡸࡃ࡭࡫ࡨࡲࡹࠐࠠࠡࠢࠣࠤࠥࠦࠠࠨࠩࠪ࢐")
        l1l1l11_opy_ = self.l11l1l1_opy_()
        self.logger.log_debug(l1l1l_opy_ (u"ࠤࡆࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࡏࡤࡲࡦ࡭ࡥࡳࡔࡨࡷࡹ࠴ࡣࡳࡧࡤࡸࡪࡥࡣ࡭࡫ࡨࡲࡹࡀࠠࡴࡹࡤ࡫࡬࡫ࡲࠡࡨ࡬ࡰࡪࠨ࢑") + str(l1l1l11_opy_))
        l11ll1l_opy_ = load_file(l1l1l11_opy_)
        config = {l1l1l_opy_ (u"ࠪࡺࡦࡲࡩࡥࡣࡷࡩࡤࡹࡷࡢࡩࡪࡩࡷࡥࡳࡱࡧࡦࠫ࢒"): False, l1l1l_opy_ (u"ࠫࡻࡧ࡬ࡪࡦࡤࡸࡪࡥࡲࡦࡵࡳࡳࡳࡹࡥࡴࠩ࢓"): False}
        client = SwaggerClient.from_spec(l11ll1l_opy_, None, None, config)
        client.swagger_spec.api_url = client.swagger_spec.api_url.replace(l1l1l_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴࠨ࢔"), CommandOptions.EM_HOST + l1l1l_opy_ (u"ࠨ࠺ࠣ࢕") + str(CommandOptions.EM_PORT))
        self.logger.log_debug(l1l1l_opy_ (u"ࠢࡄࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࡍࡢࡰࡤ࡫ࡪࡸࡒࡦࡵࡷ࠲ࡨࡸࡥࡢࡶࡨࡣࡨࡲࡩࡦࡰࡷ࠾ࠥࡩ࡯࡯ࡰࡨࡧࡹ࡫ࡤࠡࡂࠣࠦ࢖") + client.swagger_spec.api_url)
        return client
    def set_system_event_listener(self, listener):
        self.__system_event_handler = listener
    def on_system_event(self, data):
        try:
            if self.__system_event_handler is not None:
                system_event = SystemEvent.from_json(data)
                if system_event.get_type() == SystemEvent.l1ll111_opy_:
                    self.l1l111l_opy_(system_event)
                elif system_event.get_type() == SystemEvent.l1ll11l_opy_:
                    l11ll11_opy_ = NewConfigurationEvent(source = self)
                    self.__system_event_handler.on_system_event(l11ll11_opy_)
                else:
                    self.__system_event_handler.on_system_event(system_event)
            else:
                self.logger.log_debug(l1l1l_opy_ (u"ࠣࡅࡲࡲ࡫࡯ࡧࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡣࡱࡥ࡬࡫ࡲࡓࡧࡶࡸ࠳ࡵ࡮ࡠࡵࡼࡷࡹ࡫࡭ࡠࡧࡹࡩࡳࡺࠠࡴࡻࡶࡸࡪࡳ࡟ࡦࡸࡨࡲࡹࡥࡨࡢࡰࡧࡰࡪࡸࠠࡪࡵࠣࡲࡺࡲ࡬ࠣࢗ"))
        except Exception as e:
                self.logger.log_error(l1l1l_opy_ (u"ࠤࡆࡳࡳ࡬ࡩࡨࡷࡵࡥࡹ࡯࡯࡯ࡏࡤࡲࡦ࡭ࡥࡳࡔࡨࡷࡹ࠴࡯࡯ࡡࡶࡽࡸࡺࡥ࡮ࡡࡨࡺࡪࡴࡴࠡࡵࡼࡷࡹ࡫࡭ࡠࡧࡹࡩࡳࡺ࡟ࡩࡣࡱࡨࡱ࡫ࡲࠡࡶ࡫ࡶࡪࡽࠠࡦࡺࡦࡩࡵࡺࡩࡰࡰ࠱ࠤࠧ࢘"), e)
    def l1l111l_opy_(self, system_event):
        topic_ = self.l11llll_opy_(system_event.get_id())
        topic = Topic(
            name=topic_.name,
            tags=topic_.tags,
            schema=self.get_topic_schema(topic_),
            topicType=self.get_topic_type(topic_),
            topic_id=self.l1l11ll_opy_(topic_)
        )
        new_topic_event = NewTopicEvent(
            source=self,
            topic=topic
        )
        self.__system_event_handler.on_system_event(new_topic_event)
    def get_topic_type(self, topic):
        tags = topic.tags
        if TopicType.DECODED in tags:
            return TopicType.DECODED
        if TopicType.RAW in tags:
            return TopicType.RAW
        if TopicType.PROCESSED in tags:
            return TopicType.PROCESSED
        if TopicType.APPLICATION in tags:
            return TopicType.APPLICATION
        return TopicType.RAW
    def l1l11ll_opy_(self, topic):
        tags = topic.tags
        for tag in tags:
            if tag.startswith(ConfigurationManagerRest.l111ll1_opy_):
                return tag[len(ConfigurationManagerRest.l111ll1_opy_):]
        return None
    def is_system_topic(self, topic):
        tags = topic.tags
        if TopicType.SYSTEM in tags or TopicType.CONTROL in tags or TopicType.METRICS in tags or TopicType.STATUS in tags:
            return True
        return False
    def get_topic_schema(self, topic):
        l11l1ll_opy_ = None
        if topic.jsonSchema is not None:
            temp = {}
            if hasattr(topic.jsonSchema, l1l1l_opy_ (u"ࠪࡣࡤࡪࡩࡤࡶࡢࡣ࢙ࠬ")):
                for key,value in topic.jsonSchema.__dict__.iteritems():
                    if not key.startswith(l1l1l_opy_ (u"ࠫࡤࡧࡤࡥ࡫ࡷ࡭ࡴࡴࡡ࡭ࡡࡳࡶࡴࡶࡳࠨ࢚")):
                        temp[key] = value
            l11l1ll_opy_ = json.dumps(temp)
        else:
            l11l1ll_opy_ = topic.metadata
        return l11l1ll_opy_
    def l11l1l1_opy_(self):
        l1l1l_opy_ (u"ࠬ࠭ࠧࠋࠢࠣࠤࠥࠦࠠࠡࠢࡕࡩࡹࡻࡲ࡯ࡵࠣࡸ࡭࡫ࠠࡢࡤࡶࡳࡱࡻࡴࡦࠢࡳࡥࡹ࡮ࠠࡵࡱࠣࡸ࡭࡫ࠠࡴࡹࡤ࡫࡬࡫ࡲࠡࡨ࡬ࡰࡪ࠴ࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠼ࡵࡩࡹࡻࡲ࡯࠼ࠍࠤࠥࠦࠠࠡࠢࠣࠤ࢛ࠬ࠭ࠧ")
        return os.path.join(os.path.dirname(__file__), l1l1l_opy_ (u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴ࠱ࡶࡻࡦ࡭ࡧࡦࡴ࠱ࡽࡲࡲࠧ࢜"))