# test_sensor_data.py
# The information in these files is the proprietary and confidential information of Foghorn Systems, Inc., ("Foghorn").
 # Unless you have a valid license agreement with Foghorn, you may not access or use these files without the prior express written
 # consent of Foghorn.
 #
 # Copyright (c) 2016 FogHorn Systems, Inc. All rights reserved
#
from unittest import TestCase

from topic import Topic
from topic_data import TopicData
from topic_type import TopicType


class TestTopicData(TestCase):

    @classmethod
    def setUpClass(self):
        topic = Topic("name", "schema", TopicType.RAW)
        rdata = [1, 200, 31, 49]
        self.topicdata = TopicData(topic, rdata, "{}")

    def test_get_raw_data(self):
        self.assertTrue(self.topicdata.get_raw_data() != None)

    def test_get_data(self):
        self.assertTrue(self.topicdata.get_data() != None)

    def test_get_topic(self):
        self.assertTrue(self.topicdata.get_topic() != None)

    def test_get_metadata(self):
        self.assertTrue(self.topicdata.get_metadata() != None)

    def test_get_timestamp(self):
        self.assertTrue(self.topicdata.get_timestamp() == 0)

    def test_get_traceid(self):
        self.assertTrue(self.topicdata.get_traceid() == "")
