# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l11_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l1_opy_ = ord (ll_opy_ [-1])
    l1111_opy_ = ll_opy_ [:-1]
    l111_opy_ = l11l1_opy_ % len (l1111_opy_)
    l1lll_opy_ = l1111_opy_ [:l111_opy_] + l1111_opy_ [l111_opy_:]
    if l1_opy_:
        l11l_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    else:
        l11l_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    return eval (l11l_opy_)
import socket
import threading
import time
import zmq
from foghorn_sdk.cmd_option import CommandOptions
class DatabusManager(threading.Thread):
    __DBUS_PROTOCOL = l1l1l_opy_ (u"ࠥࡸࡨࡶ࠺࠰࠱ࠥࡓ")
    __STATUS_TOPIC = l1l1l_opy_ (u"ࠦ࠳ࡹࡴࡢࡶࡸࡷࠧࡔ")
    __CONTROL_TOPIC = l1l1l_opy_ (u"ࠧ࠴ࡣࡰࡰࡷࡶࡴࡲࠢࡕ")
    __METRICS_TOPIC = l1l1l_opy_ (u"ࠨ࠮࡮ࡧࡷࡶ࡮ࡩࡳࠣࡖ")
    def __init__(self, logger, client):
        self.__logger = logger
        self.__logger.log_debug(l1l1l_opy_ (u"ࠢࡅࡣࡷࡥࡧࡻࡳࡎࡣࡱࡥ࡬࡫ࡲ࠯ࡡࡢ࡭ࡳ࡯ࡴࡠࡡࠥࡗ"))
        self.__client = client
        threading.Thread.__init__(self)
        self.threadID = 1
        self.name = l1l1l_opy_ (u"ࠣࡆࡤࡸࡦࡨࡵࡴࡏࡤࡲࡦ࡭ࡥࡳࠢࡐࡩࡸࡹࡡࡨࡧࠣࡐ࡮ࡹࡴࡦࡰࡨࡶࠧࡘ")
        self.counter = 1
        self.__publisher = None
        self.__subscriber = None
        self.__exit_flag = False
        self.__context = None
        self.__run_once = False
    def add_subscriber(self, topic):
        self.__subscriber.setsockopt(zmq.SUBSCRIBE, str(topic.get_name()))
    def unsubscribe(self, topic):
        self.__subscriber.setsockopt(zmq.UNSUBSCRIBE, str(topic.get_name()))
    def publish_data(self, topic, data):
        if self.__publisher is None:
            self.__logger.log_error(l1l1l_opy_ (u"ࠤࡇࡥࡹࡧࡢࡶࡵࡐࡥࡳࡧࡧࡦࡴ࠱ࡴࡺࡨ࡬ࡪࡵ࡫ࠤࡳࡵࠠࡴࡱࡦ࡯ࡪࡺ࡙ࠡࠣ"))
            return
        try:
            frames = []
            frames.append(topic)
            frames.append(data)
            self.__publisher.send_multipart(frames)
        except Exception as e:
            self.__logger.log_error(l1l1l_opy_ (u"ࠥࡈࡦࡺࡡࡣࡷࡶࡑࡦࡴࡡࡨࡧࡵ࠲ࡵࡻࡢ࡭࡫ࡶ࡬ࠥ࡫ࡲࡳࡱࡵ࠾ࠥࠨ࡚"), e)
            raise
    def publish_status(self, data):
        self.publish_data(DatabusManager.__STATUS_TOPIC, data)
    def close(self):
        self.__logger.log_debug(l1l1l_opy_ (u"ࠦࡉࡧࡴࡢࡤࡸࡷࡒࡧ࡮ࡢࡩࡨࡶ࠳ࡩ࡬ࡰࡵࡨ࡛ࠦ"))
        self.__exit_flag = True
    def initialize(self, hwm):
        self.__logger.log_debug(l1l1l_opy_ (u"ࠧࡊࡡࡵࡣࡥࡹࡸࡓࡡ࡯ࡣࡪࡩࡷ࠴ࡩ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡧࠥ࡜"))
        self.__context = self.create_context()
        self.create_publisher(hwm)
        self.create_subscriber(hwm)
        if self.__subscriber is not None:
            self.__subscriber.setsockopt(zmq.SUBSCRIBE, DatabusManager.__CONTROL_TOPIC)
        self.daemon = True
        self.start()
    def create_publisher(self, hwm):
        try:
            self.__publisher = self.create_publisher_socket()
            if hwm > 0:
                self.__publisher.set_hwm(hwm)
            else:
                value = self.__client._FHClient__configurationManager.get_message_bus_high_water_mark()
                if value > 0:
                    self.__publisher.set_hwm(value)
            address = self.get_pub_address()
            self.__publisher.connect(address)
            self.__logger.log_debug(l1l1l_opy_ (u"ࠨࡄࡢࡶࡤࡦࡺࡹࡍࡢࡰࡤ࡫ࡪࡸ࠮ࡤࡴࡨࡥࡹ࡫࡟ࡱࡷࡥࡰ࡮ࡹࡨࡦࡴࠣࡷࡴࡩ࡫ࡦࡶࠣࠦ࡝") + str(self.__publisher) + l1l1l_opy_ (u"ࠢࠡࡂࠣࠦ࡞") + address)
        except Exception as e:
            self.__logger.log_error(l1l1l_opy_ (u"ࠣࡆࡤࡸࡦࡨࡵࡴࡏࡤࡲࡦ࡭ࡥࡳ࠰ࡦࡶࡪࡧࡴࡦࡡࡳࡹࡧࡲࡩࡴࡪࡨࡶࠥ࡫ࡲࡳࡱࡵࠤࠧ࡟"), e)
            self.__publisher = None
    def create_subscriber(self, hwm):
        try:
            self.__subscriber = self.create_subscriber_socket()
            if hwm > 0:
                self.__subscriber.set_hwm(hwm)
            else:
                value = self.__client._FHClient__configurationManager.get_message_bus_high_water_mark()
                if value > 0:
                    self.__subscriber.set_hwm(value)
            address = self.get_sub_address()
            self.__subscriber.connect(address)
            self.__logger.log_debug(l1l1l_opy_ (u"ࠤࡇࡥࡹࡧࡢࡶࡵࡐࡥࡳࡧࡧࡦࡴ࠱ࡧࡷ࡫ࡡࡵࡧࡢࡷࡺࡨࡳࡤࡴ࡬ࡦࡪࡸࠠࡴࡱࡦ࡯ࡪࡺࠠࠣࡠ") + str(self.__subscriber) + l1l1l_opy_ (u"ࠥࠤࡅࠦࠢࡡ") + address)
        except Exception as e:
            self.__logger.log_error(l1l1l_opy_ (u"ࠦࡉࡧࡴࡢࡤࡸࡷࡒࡧ࡮ࡢࡩࡨࡶ࠳ࡩࡲࡦࡣࡷࡩࡤࡹࡵࡣࡵࡦࡶ࡮ࡨࡥࡳࠢࡨࡶࡷࡵࡲࠡࠤࡢ"), e)
            self.__subscriber = None
    def run(self):
        self.__logger.log_debug(l1l1l_opy_ (u"ࠧࡊࡡࡵࡣࡥࡹࡸࡓࡡ࡯ࡣࡪࡩࡷ࠴ࡲࡶࡰࠣࡷࡹࡧࡲࡵ࠰ࠥࡣ"))
        while not self.__exit_flag:
            if self.__subscriber is None:
                break
            l1111l_opy_ = self.__subscriber.recv_multipart()
            try:
                if l1111l_opy_[0] == DatabusManager.__STATUS_TOPIC:
                   pass
                elif l1111l_opy_[0] == DatabusManager.__CONTROL_TOPIC:
                    self.__client.on_system_event(l1111l_opy_[0], l1111l_opy_[1])
                elif l1111l_opy_[0] == DatabusManager.__METRICS_TOPIC:
                    pass
                else:
                    self.__client.on_message(l1111l_opy_[0], l1111l_opy_[1])
            except Exception as e:
                self.__logger.log_error(l1l1l_opy_ (u"ࠨࡄࡢࡶࡤࡦࡺࡹࡍࡢࡰࡤ࡫ࡪࡸ࠮ࡳࡷࡱࠤࡪࡸࡲࡰࡴ࠽ࠤࠧࡤ") , e)
            if self.__run_once:
                break
        self.__logger.log_debug(l1l1l_opy_ (u"ࠢࡅࡣࡷࡥࡧࡻࡳࡎࡣࡱࡥ࡬࡫ࡲ࠯ࡴࡸࡲࠥ࡫ࡸࡪࡶ࠱ࠦࡥ"))
    def get_pub_address(self):
        host = CommandOptions.DBUS_HOST
        try:
            host = socket.gethostbyname(CommandOptions.DBUS_HOST)
        except Exception:
            pass
        return str(DatabusManager.__DBUS_PROTOCOL) + str(host) + l1l1l_opy_ (u"ࠣ࠼ࠥࡦ") + str(CommandOptions.DBUS_PUB_PORT)
    def get_sub_address(self):
        host = CommandOptions.DBUS_HOST
        try:
            host = socket.gethostbyname(CommandOptions.DBUS_HOST)
        except Exception:
            pass
        return str(DatabusManager.__DBUS_PROTOCOL) + str(host) + l1l1l_opy_ (u"ࠤ࠽ࠦࡧ") + str(CommandOptions.DBUS_SUB_PORT)
    def create_context(self):
        return zmq.Context()
    def create_subscriber_socket(self):
        return self.__context.socket(zmq.SUB)
    def create_publisher_socket(self):
        return self.__context.socket(zmq.PUB)