from unittest import TestCase

from mock import MagicMock, Mock

from cmd_option import CommandOptions
from fhapplication import FHApplication
from fhclient import FHClient


class TestFHApplication(TestCase):

    def test_get_id(self):
        FHApplication.create_command_option = MagicMock()
        app = FHApplication("MyApp", "22-100-26", "1.0", "Foghorn Systems Inc.")
        self.assertRaises(NotImplementedError, app.get_id)

    def test_get_name(self):
        FHApplication.create_command_option = MagicMock()
        app = FHApplication("MyApp", "22-100-26", "1.0", "Foghorn Systems Inc.")
        self.assertRaises(NotImplementedError, app.get_name)


    def test_get_version(self):
        FHApplication.create_command_option = MagicMock()
        app = FHApplication("MyApp", "22-100-26", "1.0", "Foghorn Systems Inc.")
        self.assertRaises(NotImplementedError, app.get_version)

    def test_get_author(self):
        FHApplication.create_command_option = MagicMock()
        app = FHApplication("MyApp", "22-100-26", "1.0", "Foghorn Systems Inc.")
        self.assertRaises(NotImplementedError, app.get_author)

    def test_shutdown(self):
        FHApplication.create_command_option = MagicMock()
        app = FHApplication("MyApp", "22-100-26", "1.0", "Foghorn Systems Inc.")
        self.assertRaises(NotImplementedError, app.shutdown)

    def test_authenticate(self):
        # test when client id is set, but client is not set _AUTH_CLIENT_SECRET the au
        FHClient.create_command_option = MagicMock()
        FHClient.create_logger = MagicMock()
        FHClient.create_config_mgr = MagicMock()
        FHClient.create_databus = MagicMock()

        mock = MagicMock()
        FHClient.get_auth_client = MagicMock(return_value=mock)
        CommandOptions.AUTH_CLIENT_ID = 'foo'
        CommandOptions.AUTH_CLIENT_SECRET = 'foo2'
        client = FHClient(Mock())

        mock.get_app_token.assert_called_once_with(CommandOptions.AUTH_CLIENT_ID, CommandOptions.AUTH_CLIENT_SECRET)

    def test_authenticate_2(self):
        # test when client is not authenticate and an exception is thrown.
        FHClient.create_command_option = MagicMock()
        FHClient.create_logger = MagicMock()
        FHClient.create_config_mgr = MagicMock()
        FHClient.create_databus = MagicMock()

        mock_auth_client = MagicMock()
        mock_auth_client.get_app_token = MagicMock(return_value=None)
        FHClient.get_auth_client = MagicMock(return_value=mock_auth_client)
        CommandOptions.AUTH_CLIENT_ID = 'foo'
        CommandOptions.AUTH_CLIENT_SECRET = 'foo2'

        self.assertRaises(Exception, FHClient.__init__)

    def test_create_command_option(self):
        mock_auth_client = MagicMock()
        FHClient.create_command_option = MagicMock()
        FHClient.create_logger = MagicMock()
        FHClient.create_config_mgr = MagicMock()
        FHClient.create_databus = MagicMock()
        FHClient.get_auth_client = MagicMock(return_value=mock_auth_client)

        client = FHClient(Mock())
        assert client.create_command_option.call_count == 1
