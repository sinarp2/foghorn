# coding: UTF-8
import sys
l1_opy_ = sys.version_info [0] == 2
l1ll_opy_ = 2048
l11_opy_ = 7
def l1l1l_opy_ (ll_opy_):
    global l1l_opy_
    l11l1_opy_ = ord (ll_opy_ [-1])
    l1111_opy_ = ll_opy_ [:-1]
    l111_opy_ = l11l1_opy_ % len (l1111_opy_)
    l1lll_opy_ = l1111_opy_ [:l111_opy_] + l1111_opy_ [l111_opy_:]
    if l1_opy_:
        l11l_opy_ = unicode () .join ([unichr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    else:
        l11l_opy_ = str () .join ([chr (ord (char) - l1ll_opy_ - (l1ll1_opy_ + l11l1_opy_) % l11_opy_) for l1ll1_opy_, char in enumerate (l1lll_opy_)])
    return eval (l11l_opy_)
class Topic(object):
    def __init__(self, name, schema, topicType, topic_id=None, tags=None):
        self.name = name
        self.type = topicType
        self.schema = schema
        self.topic_id = topic_id
        self.tags = tags
    def get_name(self):
        return str(self.name)
    def get_topic_type(self):
        return self.type
    def get_schema(self):
        return self.schema
    def get_id(self):
        return self.topic_id
    def get_tags(self):
        return self.tags
    def __set_name__(self, new_name):
        self.name = new_name
    def __repr__(self):
        return l1l1l_opy_ (u"ࠫࢀࠦࠢ࡯ࡣࡰࡩࠧࡀࠢࠨࠪ")+str(self.name)+l1l1l_opy_ (u"ࠬࠨࠬࠡࠤ࡬ࡨࠧࡀࠢࠨࠫ")+str(self.topic_id)+l1l1l_opy_ (u"࠭ࠢ࠭ࠢࠥࡸࡾࡶࡥࠣ࠼ࠥࠫࠬ")+str(self.type)+l1l1l_opy_ (u"ࠧࠣ࠮ࠣࠦࡸࡩࡨࡦ࡯ࡤࠦ࠿ࠨࠧ࠭")+str(self.schema)+l1l1l_opy_ (u"ࠨࠤࠣࢁࠬ࠮")