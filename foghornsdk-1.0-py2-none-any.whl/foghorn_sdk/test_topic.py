# test_sensor.py
# The information in these files is the proprietary and confidential information of Foghorn Systems, Inc., ("Foghorn").
 # Unless you have a valid license agreement with Foghorn, you may not access or use these files without the prior express written
 # consent of Foghorn.
 #
 # Copyright (c) 2016 FogHorn Systems, Inc. All rights reserved
#
from unittest import TestCase

from topic import Topic
from topic_type import TopicType


class TestTopic(TestCase):
    def test_get_name(self):
        topic = Topic("a_name", "a_schema", TopicType.RAW)
        self.assertEquals("a_name", topic.get_name())

    def test_get_topic_type(self):
        topic = Topic("a_name", "a_schema", TopicType.RAW)
        self.assertEquals(TopicType.RAW, topic.get_topic_type())

    def test_get_schema(self):
        topic = Topic("a_name", "a_schema", TopicType.RAW)
        self.assertEquals("a_schema", topic.get_schema())
